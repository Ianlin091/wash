import 'package:flutter/material.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class ClosetinitWidget extends StatefulWidget {
  final String imageUrl;
  final String initialCategory; // 新增預設分類參數

  ClosetinitWidget({required this.imageUrl, this.initialCategory = '全部'}); // 預設分類為"全部"

  @override
  _ClosetinitWidgetState createState() => _ClosetinitWidgetState();
}

class _ClosetinitWidgetState extends State<ClosetinitWidget> {
  late String _selectedCategory; // 使用 late 來延後初始化
  List<String> _imageUrls = [];
  String _selectedImageUrl = '';

  // 新增變數來存儲抓取到的洗滌標籤圖片 URL 和辨識出的標籤內容
  String _selectedLaundryLabelUrl = '';  // 用來存儲洗滌標籤圖片的 URL
  List<String> _recognizedLabels = [];   // 用來存儲辨識出的標籤內容

  @override
  void initState() {
    super.initState();
    _selectedCategory = widget.initialCategory; // 根據傳遞的分類來設置
    _loadImages();
  }

  void _onCategorySelected(String category) {
    setState(() {
      _selectedCategory = category;
      _loadImages();
    });
  }

  Future<void> _loadImages() async {
    List<String> categories;
    if (_selectedCategory == '全部') {
      categories = [
        '推薦', 'Polo衫', '短襯衫', '短T恤', '長襯衫', '長T恤',
        '帽T', '毛衣', '外套', '短褲', '長褲', '裙子', '墨鏡', '帽子', '圍巾'
      ];
    } else {
      categories = [_selectedCategory];
    }

    try {
      List<String> urls = [];
      for (String category in categories) {
        String imagePath = 'image/$category/';
        print("Loading images from path: $imagePath");

        final ListResult result = await FirebaseStorage.instance.ref(imagePath).listAll();
        final List<Reference> allFiles = result.items;

        for (Reference file in allFiles) {
          String url = await file.getDownloadURL();
          urls.add(url);
        }
      }

      setState(() {
        _imageUrls = urls;
        _selectedImageUrl = urls.isNotEmpty ? urls[0] : '';
      });
    } catch (e) {
      print("Error fetching images: $e");
    }
  }

  Future<void> _fetchLaundryLabel(String imageUrl) async {
    try {
      // 假設在 Firestore 中已儲存該 imageUrl 的衣物資料
      var snapshot = await FirebaseFirestore.instance
          .collection('clothes')  // 假設 collection 名為 'clothes'
          .where('imageUrl', isEqualTo: imageUrl)
          .get();

      if (snapshot.docs.isNotEmpty) {
        var document = snapshot.docs.first;
        var laundryLabelUrl = document['labelImageUrl'];  // 取得洗滌標籤圖片的 URL
        var recognizedLabels = List<String>.from(document['labelText']);  // 取得辨識出的標籤列表

        // 顯示對話框並顯示抓取到的洗滌標籤資料
        showModalBottomSheet(
          context: context,
          builder: (BuildContext context) {
            return Container(
              height: 400,  // 設定對話框的高度
              child: SingleChildScrollView( // 允許上下滾動
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('洗滌標籤', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                      SizedBox(height: 20),
                      laundryLabelUrl.isNotEmpty
                          ? Image.network(
                        laundryLabelUrl,
                        width: 100,  // 設定圖片寬度
                        height: 100, // 設定圖片高度
                        fit: BoxFit.cover, // 確保圖片按比例縮放
                      )
                          : Text('無洗滌標籤圖片'),
                      SizedBox(height: 20),
                      recognizedLabels.isNotEmpty
                          ? ListView.builder(
                        shrinkWrap: true, // 允許 ListView 在可滾動範圍內縮放
                        physics: NeverScrollableScrollPhysics(), // 禁用內部滾動，讓外部滾動控制
                        itemCount: recognizedLabels.length,
                        itemBuilder: (context, index) {
                          return Padding(
                            padding: const EdgeInsets.symmetric(vertical: 5.0),
                            child: Text(
                              recognizedLabels[index],
                              style: TextStyle(fontSize: 16),
                            ),
                          );
                        },
                      )
                          : Text('無辨識標籤'),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      } else {
        // 如果找不到對應的文件，顯示空白對話框
        showModalBottomSheet(
          context: context,
          builder: (BuildContext context) {
            return Container(
              padding: EdgeInsets.all(20),
              height: 200,
              child: Center(child: Text('此物件無洗滌標籤')),
            );
          },
        );
      }
    } catch (e) {
      print('抓取洗滌標籤時出錯: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        backgroundColor: Color.fromRGBO(223, 243, 252, 1),
        elevation: 0,
        toolbarHeight: 40,
        shadowColor: Colors.transparent,
        clipBehavior: Clip.antiAlias,
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: (){
            Navigator.popUntil(context, (route) => route.isFirst);
          },
        ),
      ),
      body: Container(
        width: 400,
        height: 800,
        decoration: BoxDecoration(
          color: Color.fromRGBO(223, 243, 252, 1),
        ),
        child: Row(
          children: <Widget>[
            Container(
              width: 100,
              margin: EdgeInsets.only(left: 10, right: 10), // 添加右邊的縫隙
              decoration: BoxDecoration(
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(20),
                  topRight: Radius.circular(20),
                  bottomLeft: Radius.circular(0),
                  bottomRight: Radius.circular(0),
                ),
                color: Color.fromRGBO(255, 255, 255, 1),
              ),
              child: Column(
                children: <Widget>[
                  Expanded(
                    child: ListView(
                      padding: EdgeInsets.only(top: 20, bottom: 20, left: 10, right: 10),
                      children: <Widget>[
                        _buildCategoryButton('推薦'),
                        _buildCategoryButton('全部'),
                        _buildCategoryButton('Polo衫'),
                        _buildCategoryButton('短襯衫'),
                        _buildCategoryButton('短T恤'),
                        _buildCategoryButton('長襯衫'),
                        _buildCategoryButton('長T恤'),
                        _buildCategoryButton('帽T'),
                        _buildCategoryButton('毛衣'),
                        _buildCategoryButton('外套'),
                        _buildCategoryButton('短褲'),
                        _buildCategoryButton('長褲'),
                        _buildCategoryButton('裙子'),
                        _buildCategoryButton('墨鏡'),
                        _buildCategoryButton('帽子'),
                        _buildCategoryButton('圍巾'),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Container(
                margin: EdgeInsets.only(right: 10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(20),
                    topRight: Radius.circular(20),
                    bottomLeft: Radius.circular(0),
                    bottomRight: Radius.circular(0),
                  ),
                  color: Color.fromRGBO(255, 255, 255, 1),
                ),
                child: Column(
                  children: [
                    // 顯示衣物圖片的 GridView
                    _imageUrls.isNotEmpty
                        ? Expanded(
                      child: GridView.builder(
                        padding: EdgeInsets.all(10),
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          crossAxisSpacing: 10,
                          mainAxisSpacing: 10,
                        ),
                        itemCount: _imageUrls.length,
                        itemBuilder: (context, index) {
                          return GestureDetector(
                            onTap: () {
                              _fetchLaundryLabel(_imageUrls[index]);  // 點擊時抓取洗滌標籤
                            },
                            child: Image.network(_imageUrls[index]),
                          );
                        },
                      ),
                    )
                        : Center(
                      child: Text('無圖片可顯示', style: TextStyle(fontSize: 24)),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCategoryButton(String category) {
    bool isSelected = _selectedCategory == category;

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () => _onCategorySelected(category),
        highlightColor: Colors.blue.withOpacity(0.2),
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: 5, vertical: 15),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: isSelected ? Colors.grey.withOpacity(0.3) : Colors.transparent,
          ),
          child: Row(
            children: <Widget>[
              Expanded(
                child: Text(
                  category,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    decoration: TextDecoration.none,
                    color: Color.fromRGBO(0, 0, 0, 1),
                    fontFamily: 'MPLUSRounded1c',
                    fontSize: 18,
                    height: 1,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
