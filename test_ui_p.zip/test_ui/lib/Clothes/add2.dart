import 'package:flutter/material.dart';
import 'package:flutter/services.dart'; // 引入 rootBundle
import 'package:image_picker/image_picker.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:tflite_flutter/tflite_flutter.dart';
import 'dart:io';
import 'dart:typed_data';
import 'package:image/image.dart' as img;
import 'dart:math' show max, min;
import 'package:firebase_storage/firebase_storage.dart';

import 'closet.dart';
import 'package:test_ui/DataModel/clothes.dart';




class Add2Widget extends StatefulWidget {
  final String clothesId;  // 接收 clothesId 参數

  Add2Widget({required this.clothesId});  // 構造函數接收並傳遞這個参數

  @override
  _Add2WidgetState createState() => _Add2WidgetState();
}

class _Add2WidgetState extends State<Add2Widget> {
  File? _image;
  List<Map<String, dynamic>>? _recognitions;
  List<String>? _labels;
  Interpreter? _interpreter;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _loadModel();
    _loadLabels();
  }

  Future<void> _loadModel() async {
    try {
      _interpreter = await Interpreter.fromAsset('assets/laundry_tags/yolov5s.tflite');
      print('Model loaded successfully');
    } catch (e) {
      print('Failed to load model: $e');
    }
  }

  Future<void> _loadLabels() async {
    try {
      final labelsData = await rootBundle.loadString('assets/laundry_tags/labels.txt');
      setState(() {
        _labels = labelsData.split('\n');
      });
    } catch (e) {
      print('Failed to load labels: $e');
    }
  }

  Future<void> _pickImage(ImageSource source) async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: source);

    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
        _busy = true;
      });
      //await _detectLabels();
    }
  }

  Future<String?> _uploadLabelImage() async {
    if (_image == null) return null;

    try {
      String labelImagePath = 'labels/${widget.clothesId}/labelImage.png';
      Reference labelImageRef = FirebaseStorage.instance.ref().child(labelImagePath);
      UploadTask uploadTask = labelImageRef.putFile(_image!);
      TaskSnapshot snapshot = await uploadTask;
      String labelImageUrl = await snapshot.ref.getDownloadURL();

      return labelImageUrl;
    } catch (e) {
      print('Error uploading label image: $e');
      return null;
    }
  }


  Future<void> _detectLabels() async {
    if (_interpreter == null || _image == null) return;

    final imageData = await _preProcessImage(_image!);

    final inputShape = [1, 640, 640, 3];
    final outputShape = _interpreter!.getOutputTensor(0).shape;
    final outputBuffer = List.generate(outputShape[0],
            (i) => List.generate(outputShape[1],
                (j) => List.filled(outputShape[2], 0.0))).reshape(outputShape);

    try {
      _interpreter!.run(imageData.reshape(inputShape), outputBuffer);

      final results = _postProcessResults(outputBuffer);

      setState(() {
        _recognitions = results;
        _busy = false;
      });

      //_saveLabelsToFirebase();
      await _saveLabelsToFirebase();  // 保存標籤和更新labelImageUrl
    } catch (e) {
      print('Error running model: $e');
      setState(() {
        _busy = false;
      });
    }
  }

  Future<Float32List> _preProcessImage(File image) async {
    final imageData = await image.readAsBytes();
    final decodedImage = img.decodeImage(imageData);
    final resizedImage = img.copyResize(decodedImage!, width: 640, height: 640);

    final inputData = Float32List(1 * 640 * 640 * 3);
    int index = 0;

    for (int y = 0; y < 640; y++) {
      for (int x = 0; x < 640; x++) {
        final pixel = resizedImage.getPixel(x, y);
        inputData[index++] = img.getRed(pixel) / 255.0;
        inputData[index++] = img.getGreen(pixel) / 255.0;
        inputData[index++] = img.getBlue(pixel) / 255.0;
      }
    }

    return inputData;
  }

  List<Map<String, dynamic>> _postProcessResults(List outputBuffer) {
    final numBoxes = outputBuffer[0].length; //25200
    final List<Map<String, dynamic>> allBoxes = [];

    for (int i = 0; i < numBoxes; i++) {
      final confidence = outputBuffer[0][i][4];

      if (confidence > 0.5) {
        final classProbs = outputBuffer[0][i].sublist(5, 77);
        final classId = classProbs.indexOf(classProbs.reduce((a, b) => max<double>(a as double, b as double)));
        final x = outputBuffer[0][i][0];
        final y = outputBuffer[0][i][1];
        final w = outputBuffer[0][i][2];
        final h = outputBuffer[0][i][3];
        allBoxes.add({
          'class': classId,
          'label': _labels != null ? _labels![classId] : 'Unknown',
          'confidence': confidence,
          'box': [x, y, w, h],
        });
      }
    }

    final List<Map<String, dynamic>> filteredResults = _nonMaximumSuppression(allBoxes);

    return filteredResults;
  }

  List<Map<String, dynamic>> _nonMaximumSuppression(List<Map<String, dynamic>> boxes, [double iouThreshold = 0.4]) {
    boxes.sort((a, b) => b['confidence'].compareTo(a['confidence']));
    final List<Map<String, dynamic>> result = [];

    while (boxes.isNotEmpty) {
      final current = boxes.removeAt(0);
      result.add(current);

      boxes.removeWhere((box) => _computeIoU(current['box'], box['box']) > iouThreshold);
    }

    return result;
  }

  double _computeIoU(List<dynamic> boxA, List<dynamic> boxB) {
    final double x1 = max(boxA[0].toDouble() - boxA[2].toDouble() / 2.0, boxB[0].toDouble() - boxB[2].toDouble() / 2.0);
    final double y1 = max(boxA[1].toDouble() - boxA[3].toDouble() / 2.0, boxB[1].toDouble() - boxB[3].toDouble() / 2.0);
    final double x2 = min(boxA[0].toDouble() + boxA[2].toDouble() / 2.0, boxB[0].toDouble() + boxB[2].toDouble() / 2.0);
    final double y2 = min(boxA[1].toDouble() + boxA[3].toDouble() / 2.0, boxB[1].toDouble() + boxB[3].toDouble() / 2.0);

    final double interArea = max(0.0, x2 - x1) * max(0.0, y2 - y1);
    final double boxAArea = boxA[2].toDouble() * boxA[3].toDouble();
    final double boxBArea = boxB[2].toDouble() * boxB[3].toDouble();
    final double iou = interArea / (boxAArea + boxBArea - interArea);

    return iou;
  }


  Future<void> _saveLabelsToFirebase() async {
    if (_recognitions != null) {
      CollectionReference clothesCollection = FirebaseFirestore.instance.collection('clothes');
      DocumentReference clothesDoc = clothesCollection.doc(widget.clothesId);

      String? labelImageUrl = await _uploadLabelImage(); // 上傳並獲取標籤圖片的URL

      // 提取所有標籤文字
      List<String> labelText = _recognitions!.map((rec) => rec['label'] as String).toList();


      // 更新現有的衣物文件
      await clothesDoc.update({
        'labelImageUrl': labelImageUrl ?? '',  // 如果上傳失敗，則為空字串
        'labelText': labelText,
      });
    }
  }

  void _showPopUp(BuildContext context, String message, {Function? onClose}) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          content: Text(message),
          actions: <Widget>[
            TextButton(
              child: Text("確認"),
              onPressed: () {
                Navigator.of(context).pop();
                if (onClose != null) {
                  onClose(); // 執行自定義的 onClose 動作
                }
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 360,
      height: 640,
      decoration: BoxDecoration(
        color : Color.fromRGBO(232, 252, 255, 1),
      ),
      child: Stack(
          children: <Widget>[
            Positioned( //虛線框框
              top: 65,
              left: 20,
              right: 20,
              child: Container(
                  width: 500,
                  height: 410,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(30),
                    image: const DecorationImage(
                        image: AssetImage('assets/images/Rectangle.png')
                    ),
                  ),
                  child: _image == null ? const Text('')
                      : Image.file(
                    _image!,
                    fit: BoxFit.cover,
                  )
              ),
            ),
            const SizedBox(
              height: 12,
            ),
            const Positioned(
                top: 25,
                left: 120,
                child: Text(
                  '請拍攝洗滌標籤',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      decoration: TextDecoration.none,
                      color: Color.fromRGBO(0, 0, 0, 1),
                      fontFamily: 'MPLUSRounded1c',
                      fontSize: 20,
                      height: 1
                  ),
                )
            ),
            Positioned(
              top: 25,
              left: 20,
              child: Container(
                width: 25,
                height: 25,
                child: Stack(
                  children: <Widget>[
                    Positioned(
                      top: -12,
                      left: -13,
                      child: IconButton(
                        onPressed: () {
                          Navigator.pop(context); // 跳回上一頁
                        },
                        icon: Icon(
                          Icons.arrow_back,
                          size: 30,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned( //照片
                top: 490,
                left: 110,
                child: Container(
                    width: 50,
                    height: 50,
                    child: Stack(
                        children: <Widget>[
                          Positioned(
                              top: 0,
                              left: 0,
                              child: Container(
                                  width: 50,
                                  height: 50,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(30),
                                    color : Color.fromRGBO(255, 255, 255, 0.6000000238418579),
                                  ),
                                  child: IconButton(
                                    onPressed: () {
                                      _pickImage(ImageSource.gallery); //開啟相簿功能
                                    },
                                    icon: Icon(
                                      Icons.photo_outlined,
                                      size: 30,
                                      color: Colors.grey,
                                    ),
                                  )
                              )
                          ),
                        ]
                    )
                )
            ),
            Positioned( //相機
                top: 490,
                left: 220,
                child: Container(
                    width: 50,
                    height: 50,
                    child: Stack(
                        children: <Widget>[
                          Positioned(
                              top: 0,
                              left: 0,
                              child: Container(
                                  width: 50,
                                  height: 50,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(30),
                                    color : Color.fromRGBO(255, 255, 255, 0.6000000238418579),
                                  ),
                                  child: IconButton(
                                    onPressed: () {
                                      _pickImage(ImageSource.camera); //開啟相機功能
                                    },
                                    icon: Icon(
                                      Icons.camera_alt_outlined,
                                      size: 30,
                                      color: Colors.grey,
                                    ),
                                  )
                              )
                          ),
                        ]
                    )
                )
            ),
            Positioned(
              top: 720,
              left: 25,
              child: TextButton(
                onPressed: () async {
                  if (_image != null) {
                    await _detectLabels();  // 執行洗滌標籤辨識

                    // 根據 Firebase 中的type字段導航到對應頁面
                    CollectionReference clothesCollection = FirebaseFirestore.instance.collection('clothes');
                    DocumentReference clothesDoc = clothesCollection.doc(widget.clothesId);

                    // 獲取類別 (type)
                    var snapshot = await clothesDoc.get();
                    if (snapshot.exists && snapshot.data() != null) {
                      var data = snapshot.data() as Map<String, dynamic>;
                      String category = data['type'] ?? '全部'; // 如果type字段不存在，默認為"全部"

                      // 根據類別進行跳轉
                      _showPopUp(context, "已成功新增服飾到衣櫥！", onClose: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => ClosetinitWidget(
                              imageUrl: '',  // 假设 `imageUrl` 是在跳轉時需要傳遞的内容
                              initialCategory: category,  // 使用識別到的類別
                            ),
                          ),
                        );
                      });
                    } else {
                      _showPopUp(context, "無法獲取類別，請稍後重試。");
                    }

                  } else {
                    _showPopUp(context, "請先拍攝或選擇一張圖片！");
                  }
                },
                child: Container(
                  width: 135,
                  height: 50,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(30),
                    color: Color.fromRGBO(255, 255, 255, 0.6),
                  ),
                  padding: EdgeInsets.symmetric(horizontal: 24, vertical: 14).copyWith(left: 45, top: 9, bottom: 9, right: 45),
                  child: Row(
                    children: <Widget>[
                      Text(
                        '確認',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          decoration: TextDecoration.none,
                          color: Color.fromRGBO(0, 0, 0, 1),
                          fontFamily: 'MPLUSRounded1c',
                          fontSize: 20,
                          height: 1,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Positioned( //略過
              top: 720,
              left: 200,
              child: TextButton(
                onPressed: () async {
                  if (_image == null) {
                    _showPopUp(context, "無洗滌標籤，已略過此步驟", onClose: () {
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(builder: (context) => ClosetinitWidget(imageUrl: '', initialCategory: '全部')),  // 跳轉到 closet.dart 頁面
                      );
                    });
                  } else {
                    _showPopUp(context, "請按下確認！");
                  }
                },
                child: Container(
                  width: 135,
                  height: 50,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(30),
                    color: Color.fromRGBO(255, 255, 255, 0.6),
                  ),
                  padding: EdgeInsets.symmetric(horizontal: 24, vertical: 14).copyWith(left: 45, top: 9, bottom: 9, right: 45),
                  child: Row(
                    children: <Widget>[
                      Text(
                        '略過',
                        textAlign: TextAlign.left,
                        style: TextStyle(
                          decoration: TextDecoration.none,
                          color: Color.fromRGBO(0, 0, 0, 1),
                          fontFamily: 'MPLUSRounded1c',
                          fontSize: 20,
                          height: 1,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Positioned( //文字框
                top: 555,
                left: 38,
                right: 38,
                child: Container(
                    width: 300,
                    height: 150,
                    decoration: BoxDecoration(
                      borderRadius : BorderRadius.only(
                        topLeft: Radius.circular(20),
                        topRight: Radius.circular(20),
                        bottomLeft: Radius.circular(20),
                        bottomRight: Radius.circular(20),
                      ),
                      color : Color.fromRGBO(195, 231, 246, 0.5),
                    )
                )
            ),
            Positioned( //提示文字
                top: 605,
                left: 60,
                right: 53,
                child: Text(
                  '若無洗滌標籤，請略過此拍攝。',
                  textAlign: TextAlign.left,
                  style: TextStyle(
                      decoration: TextDecoration.none,
                      color: Color.fromRGBO(0, 0, 0, 1),
                      fontFamily: 'MPLUSRounded1c',
                      fontSize: 15,
                      height: 1.5
                  ),
                )
            ),
            Positioned( //提示文字
                top: 575,
                left: 60,
                child: Text(
                  '‼️注意事項',
                  textAlign: TextAlign.left,
                  style: TextStyle(
                      decoration: TextDecoration.none,
                      color: Colors.redAccent,
                      fontFamily: 'MPLUSRounded1c',
                      fontSize: 15,
                      height: 1.5
                  ),
                )
            ),
          ]
      )
    );
  }
}


