class Clothes {
  String id;
  String type; // 衣物類型
  String imageUrl; // 衣物圖片URL
  String labelImageUrl; // 洗滌標籤圖片URL
  List<String> labelText; // 洗滌標籤的辨識結果

  Clothes({
    required this.id,
    required this.type,
    required this.imageUrl,
    required this.labelImageUrl,
    required this.labelText,
  });

  // 將物件轉換為 Firebase 可儲存的 Map 結構
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'type': type,
      'imageUrl': imageUrl,
      'labelImageUrl': labelImageUrl,
      'labelText': labelText,
    };
  }
  // 從 Firebase 的 Map 結構轉換為物件
  factory Clothes.fromMap(Map<String, dynamic> map) {
    return Clothes(
      id: map['id'],
      type: map['type'],
      imageUrl: map['imageUrl'],
      labelImageUrl: map['labelImageUrl'],
      labelText: List<String>.from(map['labelText'] ?? []),
    );
  }
}
