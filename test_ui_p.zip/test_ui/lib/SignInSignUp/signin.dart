import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../Calendar/Tasks/Data/Local/Data_Sources/tasks_data_provider.dart';
import '../Widget/roundtextfield.dart';
import '../homeScreen.dart';
import 'package:test_ui/Calendar/Tasks/Data/Repository/task_repository.dart';

//登入畫面
class SigninWidget extends StatefulWidget {
  @override
  _SigninWidgetState createState() => _SigninWidgetState();
}

class _SigninWidgetState extends State<SigninWidget> {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passController = TextEditingController();
  bool _isObscure = true;
  final _formkey = GlobalKey<FormState>();

  late SharedPreferences preferences;
  late TaskRepository taskRepository;

  Future<void> initPreferencesAndRepository() async {
    preferences = await SharedPreferences.getInstance();
    taskRepository = TaskRepository(taskDataProvider: TaskDataProvider(preferences));
    setState(() {}); // 更新狀態以確保 widget 正確加載
  }

  Future<User?> _signIn(
      BuildContext context, String email, String password) async {
    try {
      UserCredential userCredential = await _auth.signInWithEmailAndPassword(
          email: email, password: password);

      User? user = userCredential.user;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("成功登入"),
        ),
      );
      Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => HomescreenWidget(preferences: preferences, taskRepository: taskRepository), //跳到主畫面
          ));
      return user;
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            "登入失敗，請確認您的帳號密碼是否正確",
            style: TextStyle(
              decoration: TextDecoration.none,
              color: Colors.black,
              fontFamily: 'MPLUSRounded1c',
              fontSize: 20,
            ),
          ),
        ),
      );
      return null;
    }
  }

  @override
  void initState() {
    super.initState();
    initPreferencesAndRepository();
  }

  @override
  Widget build(BuildContext context) {
    var media = MediaQuery.of(context).size;
    return Container(
        width: 360,
        height: 640,
        decoration: BoxDecoration(
          color: Color.fromRGBO(232, 252, 255, 1),
        ),
        child: Stack(children: <Widget>[
          Positioned(
              top: 235,
              left: 0,
              right: 0,
              child: Container(
                  width: 384,
                  height: 550,
                  child: Stack(children: <Widget>[
                    Positioned(
                        top: 0,
                        left: 0,
                        right: 0,
                        child: Container(
                            width: 384,
                            height: 550,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(50),
                                topRight: Radius.circular(50),
                                bottomLeft: Radius.circular(0),
                                bottomRight: Radius.circular(0),
                              ),
                              color: Color.fromRGBO(167, 226, 252, 0.699999988079071),
                            ))),
                    Positioned(
                        top: 25,
                        left: 30,
                        child: Container(
                            width: 24,
                            height: 24,
                            decoration: BoxDecoration(
                                color: Colors.white, shape: BoxShape.circle))),
                    Positioned(
                        top: 25,
                        left: 333,
                        child: Container(
                            width: 24,
                            height: 24,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              shape: BoxShape.circle,
                            ))),
                  ]))),
          Positioned(
              top: -54,
              left: 174,
              child: Container(
                  width: 225,
                  height: 224,
                  child: Stack(children: <Widget>[
                    Positioned(
                        top: 0,
                        left: 0,
                        child: Container(
                            width: 225,
                            height: 224,
                            decoration: BoxDecoration(
                              color: Color.fromRGBO(167, 228, 254, 0.800000011920929),
                              shape: BoxShape.circle,
                            ))),
                    Positioned(
                        top: 47,
                        left: 165,
                        child: Container(
                          child: Container(
                              width: 46,
                              height: 46,
                              decoration: BoxDecoration(
                                color: Color.fromRGBO(255, 255, 255, 1),
                                shape: BoxShape.circle,
                              )),
                        )),
                    Positioned(
                        top: 100,
                        left: 68,
                        child: Container(
                            height: 50,
                            child: Text(
                              '登入',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  decoration: TextDecoration.none,
                                  color: Color.fromRGBO(255, 255, 255, 1),
                                  fontFamily: 'MPLUSRounded1c',
                                  fontSize: 45,
                                  shadows: [
                                    Shadow(
                                        blurRadius: 4,
                                        color: Color.fromRGBO(0, 0, 0, 0.2980392156862745),
                                        offset: Offset(4, 1))
                                  ],
                                  height: 1),
                            )))
                  ]))),
          Positioned(
              top: 360,
              left: 35,
              child: Container(
                  height: 30,
                  child: Text(
                    '帳號',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        decoration: TextDecoration.none,
                        color: Color.fromRGBO(0, 0, 0, 1),
                        fontFamily: 'MPLUSRounded1c',
                        fontSize: 25,
                        height: 1),
                  ))),
          Positioned(
              top: 520,
              left: 35,
              child: Container(
                  height: 30,
                  child: Text(
                    '密碼',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        decoration: TextDecoration.none,
                        color: Color.fromRGBO(0, 0, 0, 1),
                        fontFamily: 'MPLUSRounded1c',
                        fontSize: 25,
                        height: 1),
                  ))),
          Form(
              key: _formkey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  //帳號輸入區
                  Container(
                    width: 304,
                    height: 38,
                    margin: EdgeInsets.only(top: 430, right: 30, left: 30),
                    child: RoundTextField(
                      textEditingController: _emailController,
                      hintText: "帳號",
                      textInputType: TextInputType.emailAddress,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return "請輸入您的帳號";
                        }
                        return null;
                      },
                    ),
                  ),
                  SizedBox(
                    height: media.width * 0.34,
                  ),
                  //密碼輸入區
                  Container(
                    width: 304,
                    height: 38,
                    child: RoundTextField(
                      textEditingController: _passController,
                      hintText: "密碼",
                      textInputType: TextInputType.text,
                      isObsecureText: _isObscure,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return "請輸入您的密碼";
                        } else if (value.length < 6) {
                          return "密碼長度至少為6位數";
                        }
                        return null;
                      },
                      rightIcon: TextButton(
                        onPressed: () {
                          setState(() {
                            _isObscure = !_isObscure;
                          });
                        },
                        child: Container(
                          alignment: Alignment.center,
                          height: 20,
                          width: 20,
                          child: Image.asset(
                            _isObscure
                                ? "assets/icons/show_pwd_icon.png"
                                : "assets/icons/hide_pwd_icon.png",
                            width: 20,
                            height: 20,
                            fit: BoxFit.contain,
                            color: Colors.grey,
                          ),
                        ),
                      ),
                    ),
                  )
                ],
              )),
          Positioned(
              top: 690,
              left: 85,
              right: 85,
              child: TextButton(
                  onPressed: () {
                    if (_formkey.currentState!.validate()) {
                      _signIn(context, _emailController.text, _passController.text);
                    }
                  },
                  child: Container(
                    width: 178,
                    height: 50,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(30),
                        topRight: Radius.circular(30),
                        bottomLeft: Radius.circular(30),
                        bottomRight: Radius.circular(30),
                      ),
                      color: Color.fromRGBO(255, 255, 255, 0.6000000238418579),
                    ),
                    padding: EdgeInsets.symmetric(horizontal: 24, vertical: 14),
                    child: Container(
                      child: Text(
                        '登入',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            decoration: TextDecoration.none,
                            color: Color.fromRGBO(0, 0, 0, 1),
                            fontFamily: 'MPLUSRounded1c',
                            fontSize: 20,
                            height: 1),
                      ),
                    ),
                  )
              )
          )
        ])
    );
  }
}