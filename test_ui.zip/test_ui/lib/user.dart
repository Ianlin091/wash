import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:test_ui/SignInSignUp/signin.dart';
import 'package:test_ui/SignInSignUp/signup_signin.dart';

class UserWidget extends StatefulWidget {
  @override
  _UserWidgetState createState() => _UserWidgetState();
}

class _UserWidgetState extends State<UserWidget> {
  File? _image; // 用來存放選取的圖片
  String _name = ""; // 保存從 Firebase 獲取的姓名
  String _email = ""; // 保存從 Firebase 獲取的電子郵件
  String _oldPassword = ""; // 保存使用者輸入的舊密碼
  String _newPassword = ""; // 保存使用者輸入的新密碼

  // 加入控制器處理輸入框變更
  TextEditingController _nameController = TextEditingController();
  TextEditingController _emailController = TextEditingController();
  TextEditingController _oldPasswordController = TextEditingController(); // 舊密碼輸入控制器
  TextEditingController _newPasswordController = TextEditingController(); // 新密碼輸入控制器

  bool _obscureOldPassword = true; // 隱藏舊密碼
  bool _obscureNewPassword = true; // 隱藏新密碼

  @override
  void initState() {
    super.initState();
    _fetchUserData(); // 初始化時從 Firebase 獲取資料
  }

  // 從 Firebase 抓取使用者資料
  Future<void> _fetchUserData() async {
    User? user = FirebaseAuth.instance.currentUser;

    if (user != null) {
      setState(() {
        _email = user.email ?? ""; // 獲取電子郵件
        _emailController.text = _email;
      });

      // 獲取 Firestore 中的姓名
      DocumentSnapshot userData = await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .get();

      print(userData.data()); // 確認抓取的資料

      setState(() {
        _name = userData['Name']; // 獲取姓名
        _nameController.text = _name;
      });
    }
  }

  // 更新使用者資料
  Future<void> _updateUserData() async {
    User? user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      try {
        // 檢查是否需要驗證電子郵件
        if (user.emailVerified) {
          // 更新 Firestore 中的姓名
          await FirebaseFirestore.instance
              .collection('users')
              .doc(user.uid)
              .update({
            'Name': _nameController.text,
          });

          // 更新 Firebase Authentication 中的電子郵件
          if (_emailController.text != user.email) {
            await user.updateEmail(_emailController.text);
          }

          // 如果新密碼不為空，則進行密碼更新
          if (_newPasswordController.text.isNotEmpty) {
            // 需要先使用舊密碼重新驗證
            final credential = EmailAuthProvider.credential(
              email: user.email!,
              password: _oldPasswordController.text, // 使用者輸入的舊密碼
            );
            await user.reauthenticateWithCredential(credential);

            // 更新新密碼
            await user.updatePassword(_newPasswordController.text);
          }

          setState(() {
            _name = _nameController.text;
            _email = _emailController.text;
            _oldPassword = _oldPasswordController.text;
            _newPassword = _newPasswordController.text;
          });

          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text('修改成功'),
          ));
        } else {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text('請先驗證您的電子郵件地址。'),
          ));
        }
      } catch (e) {
        debugPrint('修改失敗: $e');
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('修改失敗: ${e.toString()}'),
        ));
      }
    }
  }

  // 選取圖片
  Future<void> _pickImage(ImageSource source) async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: source);
    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path); // 更新圖片狀態
      });
    }
  }

  // 顯示選擇圖片來源的底部選單
  void _showPicker(BuildContext context) {
    showModalBottomSheet(
        context: context,
        builder: (BuildContext bc) {
          return SafeArea(
            child: Wrap(
              children: <Widget>[
                ListTile(
                    leading: Icon(Icons.photo_library),
                    title: Text('相簿'),
                    onTap: () {
                      _pickImage(ImageSource.gallery); // 從相簿選取
                      Navigator.of(context).pop();
                    }),
                ListTile(
                  leading: Icon(Icons.camera_alt),
                  title: Text('相機'),
                  onTap: () {
                    _pickImage(ImageSource.camera); // 開啟相機
                    Navigator.of(context).pop();
                  },
                ),
              ],
            ),
          );
        });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          color: Color.fromRGBO(232, 252, 255, 1),
        ),
        child: Column(
          children: [
            // 返回按鈕
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Align(
                alignment: Alignment.topLeft,
                child: IconButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  icon: Icon(
                    Icons.arrow_back,
                    size: 30,
                  ),
                ),
              ),
            ),
            // 可滾動區域：包括照片、姓名、電子郵件、密碼
            Expanded(
              child: SingleChildScrollView(
                physics: BouncingScrollPhysics(),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 25.0),
                  child: Column(
                    children: [
                      // 用戶圖片部分
                      Container(
                        width: 191,
                        height: 191,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(25),
                          color: Color.fromRGBO(184, 231, 251, 1),
                        ),
                        child: _image == null
                            ? Icon(
                          Icons.person_rounded,
                          size: 180,
                          color: Color.fromRGBO(44, 146, 213, 1),
                        )
                            : ClipRRect(
                          borderRadius: BorderRadius.circular(25),
                          child: Image.file(
                            _image!,
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                      SizedBox(height: 10),
                      // 更換照片按鈕
                      TextButton(
                        onPressed: () {
                          _showPicker(context);
                        },
                        child: Container(
                          width: 180,
                          height: 50,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(30),
                            color: Color.fromRGBO(255, 255, 255, 0.6),
                          ),
                          child: Center(
                            child: Text(
                              '更換照片',
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 18,
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 20),
                      // 姓名輸入框
                      TextField(
                        controller: _nameController,
                        decoration: InputDecoration(
                          labelText: '姓名',
                          labelStyle: TextStyle(
                            color: Colors.black,
                            fontSize: 20,
                          ),
                        ),
                      ),
                      SizedBox(height: 20),
                      // 電子郵件輸入框
                      TextField(
                        controller: _emailController,
                        decoration: InputDecoration(
                          labelText: '電子郵件',
                          labelStyle: TextStyle(
                            color: Colors.black,
                            fontSize: 20,
                          ),
                        ),
                      ),
                      SizedBox(height: 20),
                      // 舊密碼輸入框
                      TextField(
                        controller: _oldPasswordController,
                        obscureText: _obscureOldPassword,
                        decoration: InputDecoration(
                          labelText: '輸入舊密碼',
                          labelStyle: TextStyle(
                            color: Colors.black,
                            fontSize: 20,
                          ),
                          suffixIcon: IconButton(
                            icon: Icon(
                              _obscureOldPassword
                                  ? Icons.visibility
                                  : Icons.visibility_off,
                            ),
                            onPressed: () {
                              setState(() {
                                _obscureOldPassword = !_obscureOldPassword;
                              });
                            },
                          ),
                        ),
                      ),
                      SizedBox(height: 20),
                      // 新密碼輸入框
                      TextField(
                        controller: _newPasswordController,
                        obscureText: _obscureNewPassword,
                        decoration: InputDecoration(
                          labelText: '輸入新密碼',
                          labelStyle: TextStyle(
                            color: Colors.black,
                            fontSize: 20,
                          ),
                          suffixIcon: IconButton(
                            icon: Icon(
                              _obscureNewPassword
                                  ? Icons.visibility
                                  : Icons.visibility_off,
                            ),
                            onPressed: () {
                              setState(() {
                                _obscureNewPassword = !_obscureNewPassword;
                              });
                            },
                          ),
                        ),
                      ),
                      SizedBox(height: 20), // 保留一點空間
                    ],
                  ),
                ),
              ),
            ),
            // 確認修改和登出按鈕
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 25.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  // 確認修改按鈕
                  TextButton(
                    onPressed: _updateUserData,
                    child: Container(
                      width: 140,
                      height: 50,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(30),
                        color: Color.fromRGBO(255, 255, 255, 0.6),
                      ),
                      child: Center(
                        child: Text(
                          '確認修改',
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 18,
                          ),
                        ),
                      ),
                    ),
                  ),
                  // 登出按鈕
                  TextButton(
                    onPressed: () async {
                      await FirebaseAuth.instance.signOut();
                      Navigator.pushAndRemoveUntil(
                        context,
                        MaterialPageRoute(builder: (context) => Signin_signupWidget()),
                            (route) => false,
                      );
                    },
                    child: Container(
                      width: 120,
                      height: 50,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(30),
                        color: Color.fromRGBO(255, 255, 255, 0.6),
                      ),
                      child: Center(
                        child: Text(
                          '登出',
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 18,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 20), // 保留一點底部空間
          ],
        ),
      ),
    );
  }
}
