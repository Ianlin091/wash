import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';


import '../../../Components/build_text_field.dart';
import '../../../Components/custom_app_bar.dart';
import '../../../Utils/util.dart';
import '../../../components/widgets.dart';
import '../../../routes/pages.dart';
import '../../../utils/font_sizes.dart';
import '../Bloc/tasks_bloc.dart';
import '../Widget/task_item_view.dart';

class TasksScreen extends StatefulWidget {
  const TasksScreen({super.key});

  @override
  State<TasksScreen> createState() => _TasksScreenState();
}

class _TasksScreenState extends State<TasksScreen> {
  TextEditingController searchController = TextEditingController();

  @override
  void initState() {
    context.read<TasksBloc>().add(FetchTaskEvent());
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return AnnotatedRegion<SystemUiOverlayStyle>(
        value: const SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
        ),
        child: ScaffoldMessenger(
            child: Scaffold(
              backgroundColor: Color.fromRGBO(232, 252, 255, 1),
              appBar: CustomAppBar(
                title: '任務列表',
                showBackArrow: true,
                actionWidgets: [
                  PopupMenuButton<int>(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20.0),
                    ),
                    elevation: 1,
                    onSelected: (value) {
                      switch (value) {
                        case 0:
                          {
                            context
                                .read<TasksBloc>()
                                .add(SortTaskEvent(sortOption: 0));
                            break;
                          }
                        case 1:
                          {
                            context
                                .read<TasksBloc>()
                                .add(SortTaskEvent(sortOption: 1));
                            break;
                          }
                        case 2:
                          {
                            context
                                .read<TasksBloc>()
                                .add(SortTaskEvent(sortOption: 2));
                            break;
                          }
                      }
                    },
                    itemBuilder: (BuildContext context) {
                      return [
                        PopupMenuItem<int>(
                          value: 0,
                          child: Row(
                            children: [
                              Icon(
                                Icons.calendar_month_outlined,
                                size: 15,
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              buildText(
                                  '依日期排序',
                                  Colors.black,
                                  textSmall,
                                  FontWeight.normal,
                                  TextAlign.start,
                                  TextOverflow.clip)
                            ],
                          ),
                        ),
                        PopupMenuItem<int>(
                          value: 1,
                          child: Row(
                            children: [
                              Icon(
                                Icons.task_outlined,
                                size: 15,
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              buildText(
                                  '已完成的任務',
                                  Colors.black,
                                  textSmall,
                                  FontWeight.normal,
                                  TextAlign.start,
                                  TextOverflow.clip)
                            ],
                          ),
                        ),
                        PopupMenuItem<int>(
                          value: 2,
                          child: Row(
                            children: [
                              Icon(
                                Icons.pending_actions_outlined,
                                size: 15,
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              buildText(
                                  '待完成的任務',
                                  Colors.black,
                                  textSmall,
                                  FontWeight.normal,
                                  TextAlign.start,
                                  TextOverflow.clip)
                            ],
                          ),
                        ),
                      ];
                    },
                    child: Padding(
                      padding: const EdgeInsets.only(right: 20),
                      child: Icon(Icons.filter_list_alt, size: 27,),
                    ),
                  ),
                ],
              ),
              body: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () => FocusScope.of(context).unfocus(),
                  child: Padding(
                      padding: const EdgeInsets.all(20),
                      child: BlocConsumer<TasksBloc, TasksState>(
                          listener: (context, state) {
                            if (state is LoadTaskFailure) {
                              ScaffoldMessenger.of(context)
                                  .showSnackBar(getSnackBar(state.error, Colors.red));
                            }

                            if (state is AddTaskFailure || state is UpdateTaskFailure) {
                              context.read<TasksBloc>().add(FetchTaskEvent());
                            }
                          }, builder: (context, state) {
                        if (state is TasksLoading) {
                          return const Center(
                            child: CupertinoActivityIndicator(),
                          );
                        }

                        if (state is LoadTaskFailure) {
                          return Center(
                            child: buildText(
                                state.error,
                                Colors.black,
                                textMedium,
                                FontWeight.normal,
                                TextAlign.center,
                                TextOverflow.clip),
                          );
                        }

                        if (state is FetchTasksSuccess) {
                          return state.tasks.isNotEmpty || state.isSearching
                              ? Column(
                            children: [
                              BuildTextField(
                                  hint: "搜尋任務",
                                  controller: searchController,
                                  inputType: TextInputType.text,
                                  prefixIcon: const Icon(
                                    Icons.search,
                                    color: Colors.grey,
                                  ),
                                  fillColor: Colors.white,
                                  onChange: (value) {
                                    context.read<TasksBloc>().add(
                                        SearchTaskEvent(keywords: value));
                                  }),
                              const SizedBox(
                                height: 20,
                              ),
                              Expanded(
                                  child: ListView.separated(
                                    shrinkWrap: true,
                                    itemCount: state.tasks.length,
                                    itemBuilder: (context, index) {
                                      return TaskItemView(
                                          taskModel: state.tasks[index]);
                                    },
                                    separatorBuilder:
                                        (BuildContext context, int index) {
                                      return const Divider(
                                        color: Colors.grey,
                                      );
                                    },
                                  ))
                            ],
                          )
                              : Center(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.add_task_rounded,
                                  size: 150,
                                  color: Colors.lightBlue,
                                ),
                                const SizedBox(
                                  height: 45,
                                ),
                                buildText(
                                    '有效地安排任務',
                                    Colors.black,
                                    textBold,
                                    FontWeight.w600,
                                    TextAlign.center,
                                    TextOverflow.clip),
                              ],
                            ),
                          );
                        }
                        return Container();
                      }))),
              floatingActionButton: FloatingActionButton(
                  child: const Icon(
                    Icons.add_rounded,
                    color: Colors.lightBlue,
                    size: 35,
                  ),
                  backgroundColor: Color.fromRGBO(210, 235, 247, 1),
                  onPressed: () {
                    Navigator.pushNamed(context, Pages.createNewTask);
                  }),
            )
        )
    );
  }
}
