import 'package:flutter/material.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/rendering.dart';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:path_provider/path_provider.dart';
import 'dart:io';
import 'package:image_gallery_saver/image_gallery_saver.dart';
import 'package:permission_handler/permission_handler.dart';

class Ootd extends StatefulWidget {
  @override
  _Ootd createState() => _Ootd();
}

class _Ootd extends State<Ootd> {
  String _selectedCategory = '';
  List<String> _imageUrls = [];
  List<Map<String, dynamic>> _selectedOutfit = [];
  Map<String, bool> _selectedFlags = {}; // 用於追蹤每張圖片的選擇狀態
  final GlobalKey _outfitKey = GlobalKey(); // GlobalKey 用於截圖

  @override
  void initState() {
    super.initState();
    _requestPermissions();
    _loadImages();
  }

  void _onCategorySelected(String category) {
    setState(() {
      _selectedCategory = category;
      _loadImages();
    });
  }

  Future<void> _loadImages() async {
    List<String> categories;
    if (_selectedCategory == '全部') {
      categories = [
        'Polo衫', '短襯衫', '短T恤', '長襯衫', '長T恤',
        '帽T', '毛衣', '外套', '短褲', '長褲', '裙子', '墨鏡', '帽子', '圍巾'
      ];
    } else {
      categories = [_selectedCategory];
    }

    try {
      List<String> urls = [];
      for (String category in categories) {
        String imagePath = 'image/$category/';
        final ListResult result = await FirebaseStorage.instance.ref(imagePath).listAll();
        final List<Reference> allFiles = result.items;

        for (Reference file in allFiles) {
          String url = await file.getDownloadURL();
          urls.add(url);
        }
      }

      setState(() {
        _imageUrls = urls;
        _selectedFlags = Map.fromIterable(urls, key: (url) => url, value: (url) => _selectedFlags[url] ?? false);
      });
    } catch (e) {
      print("Error fetching images: $e");
    }
  }

  void _selectOutfit(int index) {
    String url = _imageUrls[index];
    setState(() {
      if (_selectedFlags[url]!) {
        _selectedOutfit.removeWhere((outfit) => outfit['url'] == url);
      } else {
        _selectedOutfit.add({
          'url': url,
          'top': 50.0,
          'left': 50.0,
          'scale': 1.0,
        });
      }
      _selectedFlags[url] = !_selectedFlags[url]!;
    });
  }

  Future<void> _requestPermissions() async {
    if (!await Permission.storage.isGranted) {
      await Permission.storage.request();
    }
    var manageStatus = await Permission.manageExternalStorage.status;
    if (!manageStatus.isGranted) {
      await Permission.manageExternalStorage.request();
    }
  }

  Future<void> _saveOutfit() async {
    // 確保有權限保存圖片到相簿
    if (await Permission.storage.isGranted ||
        await Permission.manageExternalStorage.isGranted) {
      try {
        RenderRepaintBoundary boundary = _outfitKey.currentContext!.findRenderObject() as RenderRepaintBoundary;
        ui.Image image = await boundary.toImage();
        ByteData? byteData = await image.toByteData(format: ui.ImageByteFormat.png);
        Uint8List pngBytes = byteData!.buffer.asUint8List();

        // 使用 image_gallery_saver 保存圖片到相簿
        final result = await ImageGallerySaver.saveImage(
          pngBytes,
          quality: 100,
          name: 'outfit_${DateTime.now().millisecondsSinceEpoch}',
        );

        if (result['isSuccess']) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text(
              '穿搭已保存至相簿',
              style: TextStyle(
                fontSize: 14,
                color: Colors.black,
                fontWeight: FontWeight.bold,
                fontFamily: 'MPLUSRounded1c',
              ),
            ),
            backgroundColor: Color.fromRGBO(223, 243, 252, 1),
          ));
        } else {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text(
              '穿搭保存失敗',
              style: TextStyle(
                fontSize: 14,
                color: Colors.black,
                fontWeight: FontWeight.bold,
                fontFamily: 'MPLUSRounded1c',
              ),
            ),
            backgroundColor: Color.fromRGBO(223, 243, 252, 1),
          ));
        }
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(
            e.toString(),
            style: TextStyle(
              fontSize: 14,
              color: Colors.white,
              fontWeight: FontWeight.bold,
            ),
          ),
          backgroundColor: Color.fromRGBO(223, 243, 252, 1),
        ));
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(
          '拒絕存取',
          style: TextStyle(
            fontSize: 14,
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontFamily: 'MPLUSRounded1c',
          ),
        ),
        backgroundColor: Colors.red,
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        backgroundColor: Color.fromRGBO(223, 243, 252, 1),
        elevation: 0,
        toolbarHeight: 40,
        shadowColor: Colors.transparent,
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.popUntil(context, (route) => route.isFirst);
          },
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.save_alt_rounded),
            onPressed: _saveOutfit,
          ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          color: Color.fromRGBO(223, 243, 252, 1),
        ),
        child: Stack(
          children: <Widget>[
            // 上半部分：用於展示用戶搭配的衣服
            Positioned(
              width: 385,
              height: 490,
              child: RepaintBoundary( // 包裝搭配區域
                key: _outfitKey,
                child: Container(
                  margin: EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: Color.fromRGBO(255, 255, 255, 1),
                  ),
                  child: _selectedOutfit.isEmpty
                      ? Center(child: Text(
                    '在下面選擇你喜歡的服飾來創造穿搭',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 18,
                      fontFamily: 'MPLUSRounded1c',
                    ),
                  ))
                      : Stack(
                    children: _selectedOutfit.map((outfit) {
                      return Positioned(
                        top: outfit['top'],
                        left: outfit['left'],
                        child: GestureDetector(
                          onScaleUpdate: (details) {
                            setState(() {
                              outfit['scale'] = (outfit['scale'] * details.scale).clamp(0.3, 2.0);
                              outfit['top'] += details.focalPointDelta.dy;
                              outfit['left'] += details.focalPointDelta.dx;
                            });
                          },
                          child: Transform.scale(
                            scale: outfit['scale'],
                            child: Image.network(outfit['url']),
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ),
            ),
            // 下半部分：可上滑的部分，選擇衣櫃裡的衣服
            DraggableScrollableSheet(
              initialChildSize: 0.3,
              minChildSize: 0.3,
              maxChildSize: 0.7,
              builder: (BuildContext context, ScrollController scrollController) {
                return Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(20),
                      topRight: Radius.circular(20),
                    ),
                    color: Color.fromRGBO(255, 255, 255, 1),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.2),
                        spreadRadius: 2,
                        blurRadius: 8,
                        offset: Offset(0, -2),
                      ),
                    ],
                  ),
                  child: Column(
                    children: <Widget>[
                      Container(
                        margin: EdgeInsets.only(top: 8),
                        width: 40,
                        height: 5,
                        decoration: BoxDecoration(
                          color: Colors.grey,
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                        child: SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: Row(
                            children: <Widget>[
                              _buildCategoryButton('全部'),
                              _buildCategoryButton('Polo衫'),
                              _buildCategoryButton('短襯衫'),
                              _buildCategoryButton('短T恤'),
                              _buildCategoryButton('長襯衫'),
                              _buildCategoryButton('長T恤'),
                              _buildCategoryButton('帽T'),
                              _buildCategoryButton('毛衣'),
                              _buildCategoryButton('外套'),
                              _buildCategoryButton('短褲'),
                              _buildCategoryButton('長褲'),
                              _buildCategoryButton('裙子'),
                              _buildCategoryButton('墨鏡'),
                              _buildCategoryButton('帽子'),
                              _buildCategoryButton('圍巾'),
                            ],
                          ),
                        ),
                      ),
                      Expanded(
                        child: _selectedCategory.isEmpty
                            ? Center(child: Text(
                          '請選擇分類',
                          style: TextStyle(
                            fontSize: 24,
                            fontFamily: 'MPLUSRounded1c',
                          ),
                        ))
                            : _imageUrls.isNotEmpty
                            ? GridView.builder(
                          controller: scrollController,
                          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 4,
                            crossAxisSpacing: 4,
                            mainAxisSpacing: 4,
                          ),
                          itemCount: _imageUrls.length,
                          itemBuilder: (BuildContext context, int index) {
                            return GestureDetector(
                              onTap: () => _selectOutfit(index),
                              child: Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  color: _selectedFlags[_imageUrls[index]]!
                                      ? Colors.blue.withOpacity(0.3)
                                      : Colors.transparent,
                                ),
                                child: Image.network(_imageUrls[index]),
                              ),
                            );
                          },
                        )
                            : Center(child: CircularProgressIndicator()),
                      ),
                    ],
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCategoryButton(String category) {
    bool isSelected = _selectedCategory == category;

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () => _onCategorySelected(category),
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: 8, vertical: 6), // 縮小灰色區域的 padding
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: isSelected ? Colors.grey.withOpacity(0.3) : Colors.transparent,
          ),
          child: Text(
            category,
            style: TextStyle(
              color: isSelected ? Colors.black : Colors.black,
              fontSize: 16,
              fontFamily: 'MPLUSRounded1c',
            ),
          ),
        ),
      ),
    );
  }
}
