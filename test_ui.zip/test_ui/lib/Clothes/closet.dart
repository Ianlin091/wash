import 'package:flutter/material.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:test_ui/Clothes/ootd.dart';

class ClosetinitWidget extends StatefulWidget {
  final String imageUrl;
  ClosetinitWidget({required this.imageUrl});

  @override
  _ClosetinitWidgetState createState() => _ClosetinitWidgetState();
}

class _ClosetinitWidgetState extends State<ClosetinitWidget> {
  String _selectedCategory = '';
  List<String> _imageUrls = [];

  @override
  void initState() {
    super.initState();
    _loadImages();
  }

  void _onCategorySelected(String category) {
    setState(() {
      _selectedCategory = category;
      _loadImages();
    });
  }

  Future<void> _loadImages() async {
    List<String> categories;
    if (_selectedCategory == '全部') {
      categories = [
        'Polo衫', '短襯衫', '短T恤', '長襯衫', '長T恤',
        '帽T', '毛衣', '外套', '短褲', '長褲', '裙子', '墨鏡', '帽子', '圍巾'
      ];
    } else {
      categories = [_selectedCategory];
    }

    try {
      List<String> urls = [];
      for (String category in categories) {
        String imagePath = 'image/$category/';
        print("Loading images from path: $imagePath");

        final ListResult result = await FirebaseStorage.instance.ref(imagePath).listAll();
        final List<Reference> allFiles = result.items;

        for (Reference file in allFiles) {
          String url = await file.getDownloadURL();
          urls.add(url);
        }
      }

      setState(() {
        _imageUrls = urls;
      });
    } catch (e) {
      print("Error fetching images: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
          backgroundColor: Color.fromRGBO(223, 243, 252, 1),
          elevation: 0,
          toolbarHeight: 40,
          shadowColor: Colors.transparent,
          clipBehavior: Clip.antiAlias,
          leading: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: (){
              Navigator.popUntil(context, (route) => route.isFirst);
            },
          ),
          actions: [
            IconButton(
              icon: Icon(Icons.dashboard_customize),
              onPressed: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => Ootd(),
                    )
                );
              },
            )
          ]
      ),
      body: Container(
        width: 400,
        height: 800,
        decoration: BoxDecoration(
          color: Color.fromRGBO(223, 243, 252, 1),
        ),
        child: Row(
          children: <Widget>[
            Container(
              width: 100,
              margin: EdgeInsets.only(left: 10, right: 10),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(20),
                  topRight: Radius.circular(20),
                  bottomLeft: Radius.circular(0),
                  bottomRight: Radius.circular(0),
                ),
                color: Color.fromRGBO(255, 255, 255, 1),
              ),
              child: Column(
                children: <Widget>[
                  Expanded(
                    child: ListView(
                      padding: EdgeInsets.only(top: 20, bottom: 20, left: 10, right: 10),
                      children: <Widget>[
                        _buildCategoryButton('推薦'),
                        _buildCategoryButton('全部'),
                        _buildCategoryButton('Polo衫'),
                        _buildCategoryButton('短襯衫'),
                        _buildCategoryButton('短T恤'),
                        _buildCategoryButton('長襯衫'),
                        _buildCategoryButton('長T恤'),
                        _buildCategoryButton('帽T'),
                        _buildCategoryButton('毛衣'),
                        _buildCategoryButton('外套'),
                        _buildCategoryButton('短褲'),
                        _buildCategoryButton('長褲'),
                        _buildCategoryButton('裙子'),
                        _buildCategoryButton('墨鏡'),
                        _buildCategoryButton('帽子'),
                        _buildCategoryButton('圍巾'),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Container(
                margin: EdgeInsets.only(right: 10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(20),
                    topRight: Radius.circular(20),
                    bottomLeft: Radius.circular(0),
                    bottomRight: Radius.circular(0),
                  ),
                  color: Color.fromRGBO(255, 255, 255, 1),
                ),
                child: _selectedCategory.isEmpty
                    ? Center(child: Text('請選擇分類', style: TextStyle(fontSize: 24)))
                    : _imageUrls.isNotEmpty
                    ? GridView.builder(
                  padding: EdgeInsets.all(10),
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 10,
                    mainAxisSpacing: 10,
                  ),
                  itemCount: _imageUrls.length,
                  itemBuilder: (context, index) {
                    return Image.network(_imageUrls[index]);
                  },
                )
                    : Center(child: Text('無圖片可顯示', style: TextStyle(fontSize: 24))),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCategoryButton(String category) {
    bool isSelected = _selectedCategory == category;

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () => _onCategorySelected(category),
        highlightColor: Colors.blue.withOpacity(0.2),
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: 5, vertical: 15),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: isSelected ? Colors.grey.withOpacity(0.3) : Colors.transparent,
          ),
          child: Row(
            children: <Widget>[
              Expanded(
                child: Text(
                  category,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    decoration: TextDecoration.none,
                    color: Color.fromRGBO(0, 0, 0, 1),
                    fontFamily: 'MPLUSRounded1c',
                    fontSize: 18,
                    height: 1,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
