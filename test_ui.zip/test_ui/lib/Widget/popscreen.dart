import 'package:flutter/material.dart';

import '../Clothes/closet.dart';

class Popscreen1Widget extends StatefulWidget {
  final String imageUrl;  // 新增 imageUrl 參數

  Popscreen1Widget({required this.imageUrl});

  @override
  _Popscreen1WidgetState createState() => _Popscreen1WidgetState();
}

class _Popscreen1WidgetState extends State<Popscreen1Widget> {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 283,
      height: 62,
      decoration: BoxDecoration(
        boxShadow: [
          BoxShadow(
            color: Color.fromRGBO(0, 0, 0, 0.25),
            offset: Offset(0, 4),
            blurRadius: 4,
          ),
        ],
      ),
      child: Stack(
        children: <Widget>[
          Positioned(
            top: 50,
            left: 20,
            right: 20,
            child: Container(
              width: 283,
              height: 62,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(10),
                  topRight: Radius.circular(10),
                  bottomLeft: Radius.circular(10),
                  bottomRight: Radius.circular(10),
                ),
                color: Color.fromRGBO(255, 255, 255, 1),
              ),
            ),
          ),
          Positioned(
            top: 70,
            left: 65,
            child: Text(
              '🌟 已成功新增服飾到衣櫥',
              textAlign: TextAlign.center,
              style: TextStyle(
                decoration: TextDecoration.none,
                color: Color.fromRGBO(0, 0, 0, 1),
                fontFamily: 'MPLUSRounded1c',
                fontSize: 20,
                height: 1,
              ),
            ),
          ),
          Positioned(
            top: 50,
            left: 325,
            child: Container(
              width: 35,
              height: 35,
              child: Stack(
                children: <Widget>[
                  Positioned(
                    top: 1,
                    left: 1,
                    right: 1,
                    bottom: 1,
                    child: IconButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => ClosetinitWidget(
                              imageUrl: widget.imageUrl, // 使用傳遞的 imageUrl
                            ),
                          ),
                        );
                      },
                      icon: Icon(
                        Icons.highlight_off_rounded,
                        size: 19,
                        color: Colors.black,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
