import 'package:flutter/material.dart';
import 'package:test_ui/SignInSignUp/signup_signin.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../Widget/roundtextfield.dart';

class SignupWidget extends StatefulWidget {
  @override
  _SignupWidgetState createState() => _SignupWidgetState();
}

class _SignupWidgetState extends State<SignupWidget> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final CollectionReference _users = FirebaseFirestore.instance.collection("users");
  final TextEditingController _NameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passController = TextEditingController();
  bool _isObscure = true;
  final _formkey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    var media = MediaQuery.of(context).size;

    return Container(
      width: 360,
      height: 640,
      decoration: BoxDecoration(
        color: Color.fromRGBO(232, 252, 255, 1),
      ),
      child: Stack(
        children: <Widget>[
          // 背景和裝飾
          Positioned(
            top: 235,
            left: 0,
            right: 0,
            child: Container(
              width: 384,
              height: 550,
              child: Stack(
                children: <Widget>[
                  Positioned(
                    top: 0,
                    left: 0,
                    right: 0,
                    child: Container(
                      width: 384,
                      height: 550,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(50),
                          topRight: Radius.circular(50),
                        ),
                        color: Color.fromRGBO(167, 226, 252, 0.7),
                      ),
                    ),
                  ),
                  Positioned(
                    top: 25,
                    left: 30,
                    child: Container(
                      width: 24,
                      height: 24,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.circle,
                      ),
                    ),
                  ),
                  Positioned(
                    top: 25,
                    left: 333,
                    child: Container(
                      width: 24,
                      height: 24,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.circle,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          // 註冊標題
          Positioned(
            top: -54,
            left: 174,
            child: Container(
              width: 225,
              height: 224,
              child: Stack(
                children: <Widget>[
                  Positioned(
                    top: 0,
                    left: 0,
                    child: Container(
                      width: 225,
                      height: 224,
                      decoration: BoxDecoration(
                        color: Color.fromRGBO(167, 228, 254, 0.8),
                        shape: BoxShape.circle,
                      ),
                    ),
                  ),
                  Positioned(
                    top: 47,
                    left: 165,
                    child: Container(
                      width: 46,
                      height: 46,
                      decoration: BoxDecoration(
                        color: Color.fromRGBO(255, 255, 255, 1),
                        shape: BoxShape.circle,
                      ),
                    ),
                  ),
                  Positioned(
                    top: 100,
                    left: 68,
                    child: Container(
                      height: 50,
                      child: Text(
                        '註冊',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Color.fromRGBO(255, 255, 255, 1),
                          fontSize: 45,
                          shadows: [
                            Shadow(
                              blurRadius: 4,
                              color: Color.fromRGBO(0, 0, 0, 0.3),
                              offset: Offset(4, 1),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          // 表單
          Form(
            key: _formkey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                // 姓名輸入區
                Container(
                  width: 304,
                  height: 38,
                  margin: EdgeInsets.only(top: 370, right: 30, left: 30),
                  child: RoundTextField(
                    textEditingController: _NameController,
                    hintText: "姓名",
                    textInputType: TextInputType.name,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return "請輸入您的姓名";
                      }
                      return null;
                    },
                  ),
                ),
                SizedBox(height: media.width * 0.25),
                // 帳號輸入區
                Container(
                  width: 304,
                  height: 38,
                  child: RoundTextField(
                    textEditingController: _emailController,
                    hintText: "帳號",
                    textInputType: TextInputType.emailAddress,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return "請輸入您的帳號";
                      }
                      return null;
                    },
                  ),
                ),
                SizedBox(height: media.width * 0.25),
                // 密碼輸入區
                Container(
                  width: 304,
                  height: 38,
                  child: RoundTextField(
                    textEditingController: _passController,
                    hintText: "密碼",
                    textInputType: TextInputType.text,
                    isObsecureText: _isObscure,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return "請輸入您的密碼";
                      } else if (value.length < 6) {
                        return "密碼長度至少為6位數";
                      }
                      return null;
                    },
                    rightIcon: TextButton(
                      onPressed: () {
                        setState(() {
                          _isObscure = !_isObscure;
                        });
                      },
                      child: Container(
                        alignment: Alignment.center,
                        height: 20,
                        width: 20,
                        child: Image.asset(
                          _isObscure
                              ? "assets/icons/show_pwd_icon.png"
                              : "assets/icons/hide_pwd_icon.png",
                          width: 20,
                          height: 20,
                          fit: BoxFit.contain,
                          color: Colors.grey,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          // 註冊按鈕
          Positioned(
            top: 710,
            left: 85,
            right: 85,
            child: TextButton(
              onPressed: () async {
                if (_formkey.currentState!.validate()) {
                  try {
                    // 使用者註冊
                    UserCredential userCredential = await _auth.createUserWithEmailAndPassword(
                      email: _emailController.text,
                      password: _passController.text,
                    );

                    // 獲取當前使用者
                    User? user = userCredential.user;

                    // 如果使用者存在，發送驗證郵件
                    if (user != null) {
                      // 儲存使用者資料到 Firestore
                      String uid = user.uid;
                      await _users.doc(uid).set({
                        'email': _emailController.text,
                        'Name': _NameController.text,
                      });

                      // 發送驗證郵件
                      await user.sendEmailVerification();

                      // 顯示提示訊息告知使用者
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text("驗證郵件已發送，請檢查您的電子郵件")),
                      );

                      // 導向登入頁面
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => Signin_signupWidget(),
                        ),
                      );
                    }
                  } on FirebaseAuthException catch (e) {
                    switch (e.code) {
                      case 'email-already-in-use':
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text("此電子郵件地址已被使用")),
                        );
                        break;
                      default:
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text(e.message!)),
                        );
                        break;
                    }
                  } catch (e) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text(e.toString())),
                    );
                  }
                }
              },
              child: Container(
                width: 178,
                height: 50,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(30),
                  color: Color.fromRGBO(255, 255, 255, 0.6),
                ),
                padding: EdgeInsets.symmetric(horizontal: 24, vertical: 14),
                child: Center(
                  child: Text(
                    '註冊',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Color.fromRGBO(0, 0, 0, 1),
                      fontSize: 20,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
