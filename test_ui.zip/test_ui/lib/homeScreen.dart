import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:test_ui/Calendar/Tasks/Data/Repository/task_repository.dart';
import 'package:test_ui/Calendar/calendarScreen.dart';
import 'package:test_ui/ChatRobot/chatrobot.dart';
import 'package:test_ui/Clothes/add1.dart';
import 'package:test_ui/Clothes/closet.dart';
import 'package:test_ui/SignInSignUp/signin.dart';
import 'package:test_ui/Weather/weather_mix.dart';
import 'package:test_ui/Weather/weather_up.dart';
import 'package:test_ui/user.dart';

class HomescreenWidget extends StatefulWidget {
  final SharedPreferences preferences;
  final TaskRepository taskRepository;

  HomescreenWidget({required this.preferences, required this.taskRepository});

  @override
  _HomescreenWidgetState createState() => _HomescreenWidgetState();
}

class _HomescreenWidgetState extends State<HomescreenWidget> {
  final weatherUpState = WeatherUp(title: '').createState() as WeatherUpState;
  String? uploadedImageUrl;

  @override
  void initState() {
    super.initState();
    weatherUpState.enableLocationListener();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 360,
      height: 640,
      decoration: BoxDecoration(
        color: Color.fromRGBO(232, 252, 255, 1),
      ),
      child: Stack(
        children: <Widget>[
          Positioned(
            top: 123,
            left: 30,
            right: 30,
            child: Container(
              width: 50,
              height: 240,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                color: Color.fromRGBO(184, 231, 251, 1),
              ),
              child: GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => WeatherMix(title: ''),
                    ),
                  );
                },
              ),
              padding: EdgeInsets.zero,
              constraints: BoxConstraints(),
            ),
          ),
          Positioned(
            top: 133,
            left: 0,
            right: 0,
            child: weatherUpState.buildWeatherInfo(), // 確保這個方法存在並正確返回 Widget
          ),
          Positioned(
            top: 30,
            left: 25,
            child: Container(
              width: 60,
              height: 60,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: Color.fromRGBO(184, 231, 251, 1),
              ),
              child: Center(
                child: IconButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => CalendarScreen(taskRepository: widget.taskRepository),
                      ),
                    );
                  },
                  icon: Icon(
                    Icons.calendar_month_outlined,
                    size: 45,
                    color: Color.fromRGBO(44, 146, 213, 1),
                  ),
                  padding: EdgeInsets.zero,
                  constraints: BoxConstraints(),
                ),
              )
            ),
          ),
          Positioned(
            top: 400,
            right: 31,
            child: Container(
              width: 145,
              height: 145,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                color: Color.fromRGBO(184, 231, 251, 1),
              ),
              child: Center(
                child: IconButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => ClosetinitWidget(
                              imageUrl: uploadedImageUrl ?? '',
                            )
                        ),
                      );
                    },
                    icon: Icon(
                      Icons.checkroom_rounded,
                      size: 130,
                      color: Color.fromRGBO(44, 146, 213, 1),
                    ),
                  padding: EdgeInsets.zero,
                  constraints: BoxConstraints(),
                ),
              )
            ),
          ),
          Positioned(
            top: 620,
            left: 50,
            child: Container(
              width: 110,
              height: 110,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                color: Color.fromRGBO(184, 231, 251, 1),
              ),
              child: Center(
                child: IconButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => Add1Widget()),
                      );
                    },
                    icon: Icon(
                        Icons.add_rounded,
                        size: 110,
                        color: Color.fromRGBO(44, 146, 213, 1),
                    ),
                  padding: EdgeInsets.zero,
                  constraints: BoxConstraints(),
                ),
              )
            ),
          ),
          Positioned(
            top: 620,
            left: 225,
            child: Container(
              width: 110,
              height: 110,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                color: Color.fromRGBO(184, 231, 251, 1),
              ),
              child: GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => ChatPage()),
                  );
                },
                child: Center(
                  child: SizedBox(
                    width: 90,
                    height: 90,
                    child: Image.asset(
                        'assets/icons/robot.png',
                      fit: BoxFit.contain,
                    ),
                  ),
                )
              ),
            ),
          ),
          Positioned(
            top: 30,
            right: 25,
            child: Center(
              child: Container(
                  width: 60,
                  height: 60,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: Color.fromRGBO(184, 231, 251, 1),
                  ),
                  child: Center(
                    child: IconButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => UserWidget()),
                        );
                      },
                      icon: Icon(
                        Icons.person_rounded,
                        size: 50,
                        color: Color.fromRGBO(44, 146, 213, 1),
                      ),
                      padding: EdgeInsets.zero,
                      constraints: BoxConstraints(),
                    ),
                  )
              ),
            )
          ),
          Positioned(
            top: 400,
            left: 31,
            child: Center(
              child: Container(
                width: 145,
                height: 145,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(15),
                  color: Color.fromRGBO(184, 231, 251, 1),
                ),
                child: IconButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => SigninWidget()),
                    );
                  },
                  icon: Icon(
                    Icons.location_on_outlined,
                    size: 130,
                    color: Color.fromRGBO(44, 146, 213, 1),
                  ),
                ),
              ),
            )
          ),
        ],
      ),
    );
  }
}