import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:location/location.dart';
import 'package:test_ui/Weather/Icon/weather_icons.dart';
import 'package:test_ui/Weather/Location/open_weather_map_client.dart';
import 'package:test_ui/Weather/Models/forecase_result.dart';
import 'package:test_ui/Weather/Others/fore_cast_tile_widget.dart';
import 'package:test_ui/Weather/Others/info_widget.dart';
import 'package:test_ui/Weather/Others/weather_tile_widget.dart';
import 'package:test_ui/Weather/models/weather_result.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';



import 'Location/state.dart';

class WeatherMix extends StatefulWidget {
  const WeatherMix({super.key, required this.title});
  final String title;

  @override
  State<WeatherMix> createState() => _WeatherMixState();
}

class _WeatherMixState extends State<WeatherMix>{
  final controller = Get.put(MyStateController());
  var location = Location();
  late StreamSubscription listener;
  late PermissionStatus permissionStatus;

  @override
  void initState() {
    super.initState();

    WidgetsFlutterBinding.ensureInitialized().addPostFrameCallback((_) async {
      await enableLocationListener();
    });
  }

  @override
  void dispose() {
    listener.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Obx(() => Container(
            decoration: const BoxDecoration(
              color: Color.fromRGBO(223, 243, 252, 1),
            ),
            child: controller.locationData.value.latitude != null
                ? FutureBuilder(
                future: OpenWeatherMapClient().getWeather(controller.locationData.value),
                builder: (context, snapshot) {
                  if(snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(
                      child: CircularProgressIndicator(
                        color: Colors.blueAccent,
                      ),
                    );
                  } else if (snapshot.hasError) {
                    return Center(
                      child: Text(
                        snapshot.error.toString(),
                        style: const TextStyle(
                            decoration: TextDecoration.none,
                            color: Colors.black,
                            fontFamily: 'MPLUSRounded1c',
                            fontSize: 20,
                            height: 1
                        ),
                      ),
                    );
                  } else if (!snapshot.hasData) {
                    return const Center(
                      child: Text(
                        '無資料',
                        style: TextStyle(
                            decoration: TextDecoration.none,
                            color: Colors.black,
                            fontFamily: 'MPLUSRounded1c',
                            fontSize: 20,
                            height: 1
                        ),
                      ),
                    );
                  } else {
                    var data = snapshot.data as WeatherResult;
                    return Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        SizedBox(
                          height: MediaQuery.of(context).size.height / 20,
                        ),
                        Positioned(
                          child: WeatherTileWidget(
                            context: context,
                            title: (data.name != null && data.name!.isNotEmpty)
                                ? data.name
                                : '${data.coord!.lat}/${data.coord!.lon}',
                            titleFontSize: 10.0,
                            subTitle: DateFormat('yyyy/MM/dd').format(
                                DateTime.fromMillisecondsSinceEpoch(
                                    (data.dt ?? 0) * 1000
                                )
                            ),
                          ),
                        ),
                        Center(
                          child: CachedNetworkImage(
                            imageUrl: buildIcon(data.weather![0].icon ?? ''),
                            height: 200,
                            width: 200,
                            fit: BoxFit.fill,
                            progressIndicatorBuilder: (context, url, downloadProgress) => const CircularProgressIndicator(),
                            errorWidget: (context, url, err) => const Icon(
                              Icons.image,
                              color: Colors.blueAccent,
                            ),
                          ),
                        ),
                        WeatherTileWidget(
                          context: context,
                          title: '${data.main!.temp}°C',
                          titleFontSize: 40.0,
                          subTitle: '${data.weather![0].description}',
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            SizedBox(
                              width: MediaQuery.of(context).size.width / 8,
                            ),
                            InfoWidget(
                              icon: FontAwesomeIcons.wind,
                              text: '${data.wind!.speed}',
                            ),
                            InfoWidget(
                              icon: Icons.water_drop_outlined,
                              text: '${data.clouds!.all}',
                            ),
                            SizedBox(
                              width: MediaQuery.of(context).size.width / 8,
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 30,
                        ),
                        Expanded(
                            child: FutureBuilder(
                              future: OpenWeatherMapClient().getForecast(controller.locationData.value),
                              builder: (context, snapshot) {
                                if (snapshot.connectionState == ConnectionState.waiting) {
                                  return const Center(
                                    child: CircularProgressIndicator(
                                      color: Colors.black,
                                    ),
                                  );
                                } else if(snapshot.hasError) {
                                  return Center(
                                    child: Text(
                                      snapshot.error.toString(),
                                      style: const TextStyle(
                                          decoration: TextDecoration.none,
                                          color: Colors.black,
                                          fontFamily: 'MPLUSRounded1c',
                                          fontSize: 20,
                                          height: 1
                                      ),
                                    ),
                                  );
                                } else if (!snapshot.hasData) {
                                  return const Center(
                                    child: Text(
                                      '無資料',
                                      style: TextStyle(
                                          decoration: TextDecoration.none,
                                          color: Colors.black,
                                          fontFamily: 'MPLUSRounded1c',
                                          fontSize: 20,
                                          height: 1
                                      ),
                                    ),
                                  );
                                } else {
                                  var data = snapshot.data as ForecastResult;
                                  return ListView.builder(
                                      itemCount: data.list!.length ?? 0,
                                      scrollDirection: Axis.horizontal,
                                      itemBuilder: (context, index) {
                                        var item = data.list![index];
                                        return ForeCastTileWidget(
                                            temp: '${item.main!.temp}°C',
                                            time: DateFormat('yyyy/MM/dd HH:mm').format(
                                                DateTime.fromMillisecondsSinceEpoch((item.dt ?? 0) * 1000)
                                            ),
                                            imageUrl: buildIcon(item.weather![0].icon ?? '', isBigSize: false)
                                        );
                                      }
                                  );
                                }
                              },
                            )
                        )
                      ],
                    );
                  }
                }
            )
                : const Center(
              child: Text(
                '等待中',
                style: TextStyle(
                    decoration: TextDecoration.none,
                    color: Colors.black,
                    fontFamily: 'MPLUSRounded1c',
                    fontSize: 20,
                    height: 1
                ),
              ),
            )
        )
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: FloatingActionButton(
        onPressed: () async{
          controller.locationData.value = await location.getLocation();
        },
        child: const Icon(
          Icons.refresh_rounded,
          color: Colors.blueAccent,
        ),
      ),
    );
  }

  Future<void> enableLocationListener() async{
    controller.isEnableLocation.value = await location.serviceEnabled();
    if (!controller.isEnableLocation.value) {
      controller.isEnableLocation.value = await location.requestService();
      if (!controller.isEnableLocation.value) {
        return;
      }
    }

    permissionStatus = await location.hasPermission();
    if (permissionStatus == PermissionStatus.denied) {
      permissionStatus = await location.requestPermission();
      if (permissionStatus != PermissionStatus.granted) {
        return;
      }
    }

    controller.locationData.value = await location.getLocation();
    listener = location.onLocationChanged.listen((event) {
      //只需抓到最新地方
    }
    );
  }
}
