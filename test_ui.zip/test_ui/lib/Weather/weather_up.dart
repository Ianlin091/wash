import 'dart:async';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:location/location.dart';
import 'package:test_ui/Weather/Icon/weather_icons.dart';
import 'package:test_ui/Weather/Location/open_weather_map_client.dart';
import 'package:test_ui/Weather/Others/info_widget.dart';
import 'package:test_ui/Weather/Others/weather_tile_widget.dart';
import 'package:test_ui/Weather/models/weather_result.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
//import 'package:test_ui/Weather/Models/forecase_result.dart';
//import 'package:test_ui/Weather/Others/fore_cast_tile_widget.dart';
import 'Location/state.dart';


class WeatherUp extends StatefulWidget {
  const WeatherUp({super.key, required this.title});
  final String title;

  @override
  State<WeatherUp> createState() => WeatherUpState();
}

class WeatherUpState extends State<WeatherUp> {
  final controller = Get.put(MyStateController());
  var location = Location();
  late StreamSubscription listener;
  late PermissionStatus permissionStatus;

  @override
  void initState() {
    super.initState();
    WidgetsFlutterBinding.ensureInitialized().addPostFrameCallback((_) async {
      await enableLocationListener();
    });
  }

  @override
  void dispose() {
    listener.cancel();
    super.dispose();
  }

  Future<void> enableLocationListener() async {
    controller.isEnableLocation.value = await location.serviceEnabled();
    if (!controller.isEnableLocation.value) {
      controller.isEnableLocation.value = await location.requestService();
      if (!controller.isEnableLocation.value) {
        return;
      }
    }

    permissionStatus = await location.hasPermission();
    if (permissionStatus == PermissionStatus.denied) {
      permissionStatus = await location.requestPermission();
      if (permissionStatus != PermissionStatus.granted) {
        return;
      }
    }

    controller.locationData.value = await location.getLocation();
    listener = location.onLocationChanged.listen((event) {
      //只需抓到最新地方
    });
  }

  Widget buildWeatherInfo() {
    return Obx(() {
      if (controller.locationData.value.latitude == null) {
        return const Center(
          child: Text(
            '等待中',
            style: TextStyle(
              decoration: TextDecoration.none,
              color: Colors.black,
              fontFamily: 'MPLUSRounded1c',
              fontSize: 20,
              height: 15,
            ),
          ),
        );
      }

      return FutureBuilder(
        future: OpenWeatherMapClient().getWeather(controller.locationData.value),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(
                color: Colors.blueAccent,
              ),
            );
          } else if (snapshot.hasError) {
            return Center(
              child: Text(
                snapshot.error.toString(),
                style: const TextStyle(
                  decoration: TextDecoration.none,
                  color: Colors.black,
                  fontFamily: 'MPLUSRounded1c',
                  fontSize: 20,
                  height: 15,
                ),
              ),
            );
          } else if (!snapshot.hasData) {
            return const Center(
              child: Text(
                '無資料',
                style: TextStyle(
                  decoration: TextDecoration.none,
                  color: Colors.black,
                  fontFamily: 'MPLUSRounded1c',
                  fontSize: 20,
                  height: 15,
                ),
              ),
            );
          } else {
            var data = snapshot.data as WeatherResult;
            return Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                SizedBox(
                  height: MediaQuery.of(context).size.height / 60,
                ),
                WeatherTileWidget(
                  context: context,
                  title: (data.name != null && data.name!.isNotEmpty)
                      ? data.name
                      : '${data.coord!.lat}/${data.coord!.lon}',
                  titleFontSize: 30.0,
                  subTitle: DateFormat('yyyy/MM/dd').format(
                    DateTime.fromMillisecondsSinceEpoch((data.dt ?? 0) * 1000),
                  ),
                ),
                Center(
                  child: CachedNetworkImage(
                    imageUrl: buildIcon(data.weather![0].icon ?? ''),
                    height: 70,
                    width: 70,
                    fit: BoxFit.fill,
                    progressIndicatorBuilder: (context, url, downloadProgress) => const CircularProgressIndicator(),
                    errorWidget: (context, url, err) => const Icon(
                      Icons.image,
                      color: Colors.blueAccent,
                    ),
                  ),
                ),
                WeatherTileWidget(
                  context: context,
                  title: '${data.main!.temp}°C',
                  titleFontSize: 30.0,
                  subTitle: '${data.weather![0].description}',
                ),
                const SizedBox(
                  height: 15,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    SizedBox(
                      width: MediaQuery.of(context).size.width / 8,
                    ),
                    InfoWidget(
                      icon: FontAwesomeIcons.wind,
                      text: '${data.wind!.speed}',
                    ),
                    InfoWidget(
                      icon: Icons.water_drop_outlined,
                      text: '${data.clouds!.all}',
                    ),
                    SizedBox(
                      width: MediaQuery.of(context).size.width / 8,
                    ),
                  ],
                ),
                const SizedBox(
                  height: 30,
                ),
              ],
            );
          }
        },
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Obx(() => Container(
          decoration: const BoxDecoration(
            color: Color.fromRGBO(184, 231, 251, 1),
          ),
          child: buildWeatherInfo(),
        )),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          controller.locationData.value = await location.getLocation();
        },
        child: const Icon(
          Icons.refresh_rounded,
          color: Colors.blueAccent,
        ),
      ),
    );
  }
}

