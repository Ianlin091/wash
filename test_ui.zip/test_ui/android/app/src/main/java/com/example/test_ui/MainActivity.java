package com.example.test_ui;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
