import 'dart:ffi';

import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'Calendar/Tasks/Data/Repository/task_repository.dart';
import 'Calendar/Tasks/Data/Local/Data_Sources/tasks_data_provider.dart';
import 'Calendar/Routes/app_router.dart';
import 'Calendar/bloc_state_observer.dart';
import 'GuideScreen/guide1.dart';
import 'SignInSignUp/signup_signin.dart';
import 'homeScreen.dart';
import 'firebase_options.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:bloc/bloc.dart';
import 'package:test_ui/Calendar/Tasks/Presentation/Bloc/tasks_bloc.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:test_ui/Map/googleMap.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  Bloc.observer = BlocStateObserver();
  final SharedPreferences preferences = await SharedPreferences.getInstance();
  final taskRepository = TaskRepository(taskDataProvider: TaskDataProvider(preferences));
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(MyApp(taskRepository: taskRepository, preferences: preferences));
}

class MyApp extends StatelessWidget {
  final SharedPreferences preferences;
  final TaskRepository taskRepository;

  MyApp({required this.taskRepository, required this.preferences});

  @override
  Widget build(BuildContext context) {
    return RepositoryProvider.value(
      value: taskRepository,
      child: MultiBlocProvider(
        providers: [
          BlocProvider<TasksBloc>(
            create: (context) => TasksBloc(taskRepository),
          ),
        ],
        child: MaterialApp(
          localizationsDelegates: [
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          supportedLocales: [
            const Locale('zh', 'TW'), // 繁體中文
            const Locale('en', ''),   // 英文
          ],
          home: InitialWidget(taskRepository: taskRepository, preferences: preferences),
          onGenerateRoute: (routeSettings) => onGenerateRoute(routeSettings, taskRepository),
        )
      )
    );
  }
}

class InitialWidget extends StatefulWidget {
  final SharedPreferences preferences;
  final TaskRepository taskRepository;

  InitialWidget({required this.taskRepository, required this.preferences});

  @override
  _InitialWidgetState createState() => _InitialWidgetState();
}

class _InitialWidgetState extends State<InitialWidget> {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  @override
  void initState() {
    super.initState();
    // 延遲2秒後顯示首頁
    Future.delayed(Duration(seconds: 2), () {
      if (_auth.currentUser != null) {
        // 如果用戶已經登錄，顯示 HomescreenWidget
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => HomescreenWidget(taskRepository: widget.taskRepository, preferences: widget.preferences)),
        );
      } else {
        // 如果用戶未登錄，顯示 Signin_signupWidget
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => Signin_signupWidget()),
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => Guide1Widget()), // 跳到導覽頁1
        );
      },
      child: Container(
        width: 360,
        height: 640,
        decoration: BoxDecoration(
          color: Color.fromRGBO(232, 252, 255, 1),
        ),
        child: Stack(
          children: <Widget>[
            Positioned(
              top: 560,
              left: -95,
              right: -95,
              child: Container(
                alignment: Alignment.center,
                height: 35,
                child: Text(
                  '慧新衣笑',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    decoration: TextDecoration.none,
                    color: Color.fromRGBO(0, 0, 0, 1),
                    fontFamily: 'MPLUSRounded1c',
                    fontSize: 40,
                    height: 0.5,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ),
            Positioned(
              top: 200,
              left: 65,
              child: Container(
                width: 24,
                height: 24,
                decoration: BoxDecoration(
                  color: Color.fromRGBO(184, 231, 251, 1),
                  shape: BoxShape.circle,
                ),
              ),
            ),
            Positioned(
              top: 205,
              left: 80,
              child: Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  color: Color.fromRGBO(255, 255, 255, 1),
                  shape: BoxShape.circle,
                ),
              ),
            ),
            Positioned(
              top: 280,
              left: 320,
              child: Container(
                width: 24,
                height: 24,
                decoration: BoxDecoration(
                  color: Color.fromRGBO(184, 231, 251, 1),
                  shape: BoxShape.circle,
                ),
              ),
            ),
            Positioned(
              top: 680,
              left: 220,
              child: Container(
                width: 24,
                height: 24,
                decoration: BoxDecoration(
                  color: Color.fromRGBO(184, 231, 251, 1),
                  shape: BoxShape.circle,
                ),
              ),
            ),
            Positioned(
              top: 290,
              left: 335,
              child: Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  color: Color.fromRGBO(255, 255, 255, 1),
                  shape: BoxShape.circle,
                ),
              ),
            ),
            Positioned(
              top: 690,
              left: 235,
              child: Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  color: Color.fromRGBO(255, 255, 255, 1),
                  shape: BoxShape.circle,
                ),
              ),
            ),
            Positioned(
              top: 650,
              left: 50,
              child: Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage('assets/star/Star 1.png'),
                    fit: BoxFit.fitWidth,
                  ),
                ),
              ),
            ),
            Positioned(
              top: 150,
              left: 220,
              child: Container(
                width: 24,
                height: 24,
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage('assets/star/Star 2.png'),
                    fit: BoxFit.fitWidth,
                  ),
                ),
              ),
            ),
            Positioned(
              top: 580,
              left: 320,
              child: Container(
                width: 20,
                height: 20,
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage('assets/star/Star 3.png'),
                    fit: BoxFit.fitWidth,
                  ),
                ),
              ),
            ),
            Positioned(
              top: 50,
              left: -125,
              bottom: 100,
              child: Container(
                width: 650,
                height: 650,
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage('assets/images/Logo1.png'),
                    fit: BoxFit.fitWidth,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
