import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import 'package:location/location.dart' as loc;
import 'package:flutter_google_maps_webservices/places.dart';
import 'package:flutter_google_maps_webservices/directions.dart' as directions;
import 'package:test_ui/api/map_api.dart';
import 'package:url_launcher/url_launcher.dart';

class MapPage extends StatefulWidget {
  const MapPage({super.key});

  @override
  State<MapPage> createState() => _MapPageState();
}

class _MapPageState extends State<MapPage> {
  // Controllers and variables
  late loc.Location _locationController;
  final Completer<GoogleMapController> _mapController = Completer<GoogleMapController>();
  static const LatLng _pGooglePlex = LatLng(37.4223, -122.0848);
  LatLng? _currentP;

  // Data for map markers and polylines
  Map<PolylineId, Polyline> polylines = {};
  List<Marker> _markers = [];
  List<PlacesSearchResult> _laundromats = [];
  Map<String, double> _distanceMap = {};

  // Selected laundromat and route info
  PlacesSearchResult? _selectedLaundromat;
  String? _routeDistance;
  String? _routeDuration;

  @override
  void initState() {
    super.initState();
    _locationController = loc.Location();
    getLocationUpdates();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          _buildMap(),
          _buildBackButton(),
          if (_selectedLaundromat != null) _buildLaundromatDetails(),
          _buildLaundromatList(),
        ],
      ),
    );
  }

  // Widget to display Google Map
  Widget _buildMap() {
    return _currentP == null
        ? const Center(child: CircularProgressIndicator())
        : GoogleMap(
      onMapCreated: (GoogleMapController controller) => _mapController.complete(controller),
      initialCameraPosition: CameraPosition(target: _pGooglePlex, zoom: 14),
      markers: _markers.toSet(),
      polylines: Set<Polyline>.of(polylines.values),
      myLocationEnabled: true,
      myLocationButtonEnabled: true,
      zoomControlsEnabled: false,
    );
  }

  // Floating action button for future menu options
  Widget _buildBackButton() {
    return Positioned(
      left: 10,
      top: 40,
      child: FloatingActionButton(
        child: Icon(Icons.arrow_back),  // 將圖案改為返回箭頭
        onPressed: () {
          Navigator.pop(context);  // 返回上一頁
        },
      ),
    );
  }


  // Laundromat detail widget at the bottom of the screen
  Widget _buildLaundromatDetails() {
    return Positioned(
      bottom: 0,
      left: 0,
      right: 0,
      child: Container(
        color: Colors.white,
        padding: EdgeInsets.all(8.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              _selectedLaundromat!.name,
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            Text('Distance: $_routeDistance'),
            Text('Duration: $_routeDuration'),
            ElevatedButton(
              onPressed: () {
                _startNavigation(LatLng(
                  _selectedLaundromat!.geometry!.location.lat,
                  _selectedLaundromat!.geometry!.location.lng,
                ));
              },
              child: Text('開始導航'),
            ),
          ],
        ),
      ),
    );
  }

  // List of laundromats shown in a draggable sheet
  Widget _buildLaundromatList() {
    return DraggableScrollableSheet(
      initialChildSize: 0.3,
      minChildSize: 0.1,
      maxChildSize: 0.9,
      builder: (BuildContext context, ScrollController scrollController) {
        return Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(20),
              topRight: Radius.circular(20),
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.5),
                spreadRadius: 5,
                blurRadius: 7,
                offset: Offset(0, 3),
              ),
            ],
          ),
          child: Column(
            children: [
              Expanded(
                child: ListView.builder(
                  controller: scrollController,
                  itemCount: _laundromats.length,
                  itemBuilder: (context, index) {
                    return _buildLaundromatItem(index);
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // Individual laundromat item in the list
  Widget _buildLaundromatItem(int index) {
    final laundromat = _laundromats[index];
    return ListTile(
      leading: laundromat.photos != null && laundromat.photos!.isNotEmpty
          ? Image.network(
        'https://maps.googleapis.com/maps/api/place/photo?maxwidth=100&photoreference=${laundromat.photos![0].photoReference}&key=$GOOGLE_MAPS_API_KEY',
        width: 50,
        height: 50,
        fit: BoxFit.cover,
      )
          : Image.asset(
        'assets/images/image1.png',
        width: 50,
        height: 50,
        fit: BoxFit.cover,
      ),
      title: Text(laundromat.name),
      subtitle: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('距離: ${_distanceMap[laundromat.placeId]?.toStringAsFixed(2) ?? "N/A"} km'),
          if (laundromat.rating != null)
            Row(
              children: List.generate(5, (index) {
                return Icon(
                  index < laundromat.rating!.round() ? Icons.star : Icons.star_border,
                  color: Colors.amber,
                  size: 16,
                );
              }),
            ),
        ],
      ),
      onTap: () => _navigateToLaundromat(laundromat),
    );
  }

  // Location and map updates
  Future<void> getLocationUpdates() async {
    bool _serviceEnabled;
    loc.PermissionStatus _permissionGranted;

    _serviceEnabled = await _locationController.serviceEnabled();
    if (!_serviceEnabled) {
      _serviceEnabled = await _locationController.requestService();
      if (!_serviceEnabled) return;
    }

    _permissionGranted = await _locationController.hasPermission();
    if (_permissionGranted == loc.PermissionStatus.denied) {
      _permissionGranted = await _locationController.requestPermission();
      if (_permissionGranted != loc.PermissionStatus.granted) return;
    }

    _locationController.onLocationChanged.listen((loc.LocationData currentLocation) {
      if (currentLocation.latitude != null && currentLocation.longitude != null) {
        setState(() {
          _currentP = LatLng(currentLocation.latitude!, currentLocation.longitude!);
          _cameraToPosition(_currentP!);
        });
        searchNearbyLaundromats(currentLocation.latitude!, currentLocation.longitude!);
      }
    });
  }

  Future<void> _cameraToPosition(LatLng pos) async {
    final GoogleMapController controller = await _mapController.future;
    CameraPosition _newCameraPosition = CameraPosition(target: pos, zoom: 14);
    await controller.animateCamera(CameraUpdate.newCameraPosition(_newCameraPosition));
  }

  // Laundromat search and display on map
  Future<void> searchNearbyLaundromats(double latitude, double longitude) async {
    final _places = GoogleMapsPlaces(apiKey: GOOGLE_MAPS_API_KEY);
    final currentLocation = LatLng(latitude, longitude);

    final response = await _places.searchNearbyWithRadius(
      Location(lat: currentLocation.latitude, lng: currentLocation.longitude),
      5000,
      type: 'laundry',
    );

    if (response.status == 'OK') {
      setState(() {
        _markers.clear();
        _laundromats = response.results;
        _distanceMap.clear();

        for (var laundromat in _laundromats) {
          double distance = calculateDistance(
            currentLocation.latitude,
            currentLocation.longitude,
            laundromat.geometry!.location.lat,
            laundromat.geometry!.location.lng,
          );
          _distanceMap[laundromat.placeId] = distance;
        }

        _laundromats.sort((a, b) =>
            (_distanceMap[a.placeId] ?? double.infinity).compareTo(_distanceMap[b.placeId] ?? double.infinity));

        for (var result in _laundromats) {
          _markers.add(
            Marker(
              markerId: MarkerId(result.placeId),
              position: LatLng(result.geometry!.location.lat, result.geometry!.location.lng),
              infoWindow: InfoWindow(title: result.name, snippet: result.vicinity),
            ),
          );
        }
      });
    } else {
      print(response.errorMessage);
    }
  }

  // Route calculation and polyline display
  Future<void> _getPolyline(LatLng origin, LatLng destination) async {
    try {
      final directionsApi = directions.GoogleMapsDirections(apiKey: GOOGLE_MAPS_API_KEY);
      final response = await directionsApi.directionsWithLocation(
        directions.Location(lat: origin.latitude, lng: origin.longitude),
        directions.Location(lat: destination.latitude, lng: destination.longitude),
        travelMode: directions.TravelMode.driving,
      );

      if (response.status == 'OK') {
        final route = response.routes[0];
        final leg = route.legs[0];

        setState(() {
          _routeDistance = leg.distance.text;
          _routeDuration = leg.duration.text;
        });

        final points = PolylinePoints().decodePolyline(route.overviewPolyline.points);
        List<LatLng> polylineCoordinates = points.map((point) => LatLng(point.latitude, point.longitude)).toList();

        setState(() {
          polylines.clear();
          polylines[PolylineId("poly")] = Polyline(
            polylineId: PolylineId("poly"),
            color: Colors.blue,
            points: polylineCoordinates,
            width: 3,
          );
        });
      } else {
        print('Directions API response status: ${response.status}');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('無法獲取路線。錯誤: ${response.status}')),
        );
      }
    } catch (e) {
      print('Error in _getPolyline: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('獲取路線時發生錯誤。請稍後再試。')),
      );
    }
  }

  // Navigation functionality
  Future<void> _navigateToLaundromat(PlacesSearchResult laundromat) async {
    final destination = LatLng(
      laundromat.geometry!.location.lat,
      laundromat.geometry!.location.lng,
    );

    final url =
        'https://www.google.com/maps/dir/?api=1&destination=${destination.latitude},${destination.longitude}&travelmode=driving';
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('無法啟動導航。請確保您已安裝Google Maps。')),
      );
    }
  }

  // Helper function for navigation button
  void _startNavigation(LatLng destination) async {
    final url =
        'https://www.google.com/maps/dir/?api=1&destination=${destination.latitude},${destination.longitude}&travelmode=driving';
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('無法啟動導航。請確保您已安裝Google Maps。')),
      );
    }
  }

  // Distance calculation helper function
  double calculateDistance(double lat1, double lon1, double lat2, double lon2) {
    const R = 6371; // Radius of Earth in kilometers
    var dLat = _toRadians(lat2 - lat1);
    var dLon = _toRadians(lon2 - lon1);
    var a = sin(dLat / 2) * sin(dLat / 2) +
        cos(_toRadians(lat1)) * cos(_toRadians(lat2)) * sin(dLon / 2) * sin(dLon / 2);
    var c = 2 * atan2(sqrt(a), sqrt(1 - a));
    return R * c;
  }

  // Helper function to convert degrees to radians
  double _toRadians(double degree) {
    return degree * pi / 180;
  }
}
