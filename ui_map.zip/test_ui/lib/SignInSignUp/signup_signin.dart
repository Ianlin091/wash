import 'package:flutter/material.dart';
import 'package:test_ui/SignInSignUp/signin.dart';
import 'package:test_ui/SignInSignUp/signup.dart';

//選擇登入註冊畫面
class Signin_signupWidget extends StatefulWidget {
  @override
  _Signin_signupWidgetState createState() => _Signin_signupWidgetState();
}

class _Signin_signupWidgetState extends State<Signin_signupWidget> {
  @override
  Widget build(BuildContext context) {
    return Container(
        width: 360,
        height: 640,
        decoration: BoxDecoration(
          color : Color.fromRGBO(232, 252, 255, 1),
        ),
        child: Stack(
            children: <Widget>[
              Positioned(
                  bottom: 350,
                  left: -55,
                  child: Container(
                      width: 500,
                      height: 500,
                      decoration: BoxDecoration(
                        image : DecorationImage(
                            image: AssetImage('assets/images/Logo1.png'),
                            fit: BoxFit.fitWidth
                        ),
                      )
                  )
              ),
              Positioned(
                  top: 310,
                  left: -60,
                  child: Container(
                      width: 500,
                      height: 600,
                      decoration: BoxDecoration(
                        color : Colors.white,
                        borderRadius : BorderRadius.all(Radius.elliptical(520, 490)),
                      )
                  )
              ),
              Positioned(
                  top: 400,
                  left: 95,
                  child: Container(
                      height: 35,
                      child: Text(
                        'Welcome',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            decoration: TextDecoration.none,
                            color: Color.fromRGBO(0, 0, 0, 1),
                            fontFamily: 'MPLUSRounded1c',
                            fontSize: 40,
                            height: 1
                        ),)
                  )
              ),
              Positioned(
                  top: 510,
                  left: 26,
                  right: 26,
                  child: TextButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => SigninWidget()) //跳到登入畫面
                          );
                        },
                      child: Container(
                        width: 310,
                        height: 60,
                        decoration: BoxDecoration(
                          borderRadius : BorderRadius.only(
                            topLeft: Radius.circular(30),
                            topRight: Radius.circular(30),
                            bottomLeft: Radius.circular(30),
                            bottomRight: Radius.circular(30),
                          ),
                          color : Color.fromRGBO(184, 231, 251, 1),
                        ),
                        padding: EdgeInsets.symmetric(horizontal: 24, vertical: 14),
                        child: Container(
                          height: 20,
                          child: Text(
                            '登入',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                decoration: TextDecoration.none,
                                color: Color.fromRGBO(24, 158, 255, 1),
                                fontFamily: 'MPLUSRounded1c',
                                fontSize: 29,
                                height: 1
                            ),),
                        ),
                      )
                  )
              ),
              Positioned(
                  top: 650,
                  left: 26,
                  right: 26,
                  child: TextButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => SignupWidget()) //跳到註冊畫面
                        );
                      },
                      child: Container(
                        width: 310,
                        height: 60,
                        decoration: BoxDecoration(
                          borderRadius : BorderRadius.only(
                            topLeft: Radius.circular(30),
                            topRight: Radius.circular(30),
                            bottomLeft: Radius.circular(30),
                            bottomRight: Radius.circular(30),
                          ),
                          color : Color.fromRGBO(184, 231, 251, 1),
                        ),
                        padding: EdgeInsets.symmetric(horizontal: 24, vertical: 14),
                        child: Container(
                          height: 20,
                          child: Text(
                            '註冊',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                decoration: TextDecoration.none,
                                color: Color.fromRGBO(24, 158, 255, 1),
                                fontFamily: 'MPLUSRounded1c',
                                fontSize: 29,
                                height: 1
                            ),),
                        ),
                      )
                  )
              ),
            ]
        )
    );
  }
}