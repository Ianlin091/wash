import 'dart:async';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:screenshot/screenshot.dart';
import 'package:flutter_tflite/flutter_tflite.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart';
import 'package:test_ui/Widget/popscreen.dart';

import '../api/remove_bg.dart';

//洗滌標籤辨識畫面
class Add2Widget extends StatefulWidget {
  @override
  _Add2WidgetState createState() => _Add2WidgetState();
}

class _Add2WidgetState extends State<Add2Widget> {
  File? filePath;
  Uint8List? imageFile;
  String? imagePath;
  ScreenshotController controller = ScreenshotController();
  String label = '';
  double confidence = 0.0;
  String? uploadedImageUrl;

  Future<void> _tfliteInit() async{
    String? res = await Tflite.loadModel(
        model: "assets/closet_models/model_unquant.tflite", //洗衣標籤模型
        labels: "assets/closet_models/labels.txt", //洗衣標籤
        numThreads: 1,
        isAsset: true,
        useGpuDelegate: false
    );
  }

  Future<void> getImageAndRemoveBg(ImageSource source) async{
    try {
      final pickedImage = await ImagePicker().pickImage(source: source);
      if (pickedImage != null) {
        imagePath = pickedImage.path;
        imageFile = await pickedImage.readAsBytes();
        setState(() {
          filePath = File(pickedImage.path);
        });

        //移除背景
        Uint8List? imageData = await RemoveBg().removeBgApi(imagePath!);
        if(imageData != null) {
          setState(() {
            imageFile = imageData;
            filePath = File(pickedImage.path);
          });
        }

        var recognitions = await Tflite.runModelOnImage(
            path: imagePath!,
            imageMean: 0.0,
            imageStd: 255.0,
            numResults: 2,
            threshold: 0.2,
            asynch: true
        );

        if (recognitions == null || recognitions.isEmpty) {
          print("recognitions is Null or Empty");
          return;
        }
        print(recognitions.toString());
        setState(() {
          confidence = (recognitions[0]['confidence'] * 100);
          label = recognitions[0]['label'].toString();
        });
      }
    } catch(e) {
      print('Error: $e');
      imageFile = null;
      setState(() {});
    }
  }

  Future<void> saveImage(BuildContext context) async {
    try {
      String fileName = basename(imagePath!);
      Reference firebaseStorageRef = FirebaseStorage.instance.ref().child(fileName);
      UploadTask uploadTask = firebaseStorageRef.putData(imageFile!);
      TaskSnapshot snapshot = await uploadTask;
      uploadedImageUrl = await snapshot.ref.getDownloadURL(); // 獲取上傳後的圖片 URL
      print("Picture uploaded");
      setState(() {});
    } catch (e) {
      print('Error: $e');
    }
  }

  @override
  void dispose() {
    super.dispose();
    Tflite.close();
  }

  @override
  void initState() {
    super.initState();
    _tfliteInit();
  }

  @override
  Widget build(BuildContext context) {
    void _showPopUp(BuildContext context) {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return Popscreen1Widget(imageUrl: uploadedImageUrl ?? ''); // 傳遞 imageUrl 或空字串
        },
      );
    }


    return Container(
      width: 360,
      height: 640,
      decoration: BoxDecoration(
        color : Color.fromRGBO(232, 252, 255, 1),
      ),
      child: Stack(
          children: <Widget>[
            Positioned( //虛線框框
              top: 65,
              left: 20,
              right: 20,
              child: Container(
                  width: 500,
                  height: 410,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(30),
                    image: const DecorationImage(
                        image: AssetImage('assets/images/Rectangle.png')
                    ),
                  ),
                  child: filePath == null ? const Text('')
                      : Image.file(
                    filePath!,
                    fit: BoxFit.fill,
                  )
              ),
            ),
            const SizedBox(
              height: 12,
            ),
            Positioned(
              top: 25,
              left: 120,
              child: Text(
                '請拍攝洗滌標籤',
                textAlign: TextAlign.center,
                style: TextStyle(
                  decoration: TextDecoration.none,
                  color: Color.fromRGBO(0, 0, 0, 1),
                  fontFamily: 'MPLUSRounded1c',
                  fontSize: 20,
                  height: 1
                ),
              )
            ),
            Positioned( //返回鍵
                top: 25,
                left: 20,
                child: Container(
                    width: 25,
                    height: 25,
                    child: Stack(
                        children: <Widget>[
                          Positioned(
                              top: -12,
                              left: -13,
                              child: IconButton(
                                onPressed: () {
                                  Navigator.pop(context); //跳回上一頁
                                },
                                icon: Icon(
                                  Icons.arrow_back,
                                  size: 30,
                                ),
                              )
                          ),
                        ]
                    )
                )
            ),
            Positioned( //照片
                top: 490,
                left: 110,
                child: Container(
                    width: 50,
                    height: 50,
                    child: Stack(
                        children: <Widget>[
                          Positioned(
                              top: 0,
                              left: 0,
                              child: Container(
                                  width: 50,
                                  height: 50,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(30),
                                    color : Color.fromRGBO(255, 255, 255, 0.6000000238418579),
                                  ),
                                  child: IconButton(
                                    onPressed: () {
                                      getImageAndRemoveBg(ImageSource.gallery); //開啟相簿功能
                                    },
                                    icon: Icon(
                                      Icons.photo_outlined,
                                      size: 30,
                                      color: Colors.grey,
                                    ),
                                  )
                              )
                          ),
                        ]
                    )
                )
            ),
            Positioned( //相機
                top: 490,
                left: 220,
                child: Container(
                    width: 50,
                    height: 50,
                    child: Stack(
                        children: <Widget>[
                          Positioned(
                              top: 0,
                              left: 0,
                              child: Container(
                                  width: 50,
                                  height: 50,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(30),
                                    color : Color.fromRGBO(255, 255, 255, 0.6000000238418579),
                                  ),
                                  child: IconButton(
                                    onPressed: () {
                                      getImageAndRemoveBg(ImageSource.camera); //開啟相機功能
                                    },
                                    icon: Icon(
                                      Icons.camera_alt_outlined,
                                      size: 30,
                                      color: Colors.grey,
                                    ),
                                  )
                              )
                          ),
                        ]
                    )
                )
            ),
            Positioned( //確認
              top: 720,
              left: 25,
              child: TextButton(
                  onPressed: () {
                    _showPopUp(context); //浮動視窗
                  },
                  child: Container(
                    width: 135,
                    height: 50,
                    decoration: BoxDecoration(
                      borderRadius : BorderRadius.only(
                        topLeft: Radius.circular(30),
                        topRight: Radius.circular(30),
                        bottomLeft: Radius.circular(30),
                        bottomRight: Radius.circular(30),
                      ),
                      color : Color.fromRGBO(255, 255, 255, 0.6000000238418579),
                    ),
                    padding: EdgeInsets.symmetric(horizontal: 24, vertical: 14).copyWith(left: 45, top: 9, bottom: 9, right: 45),
                    child: Row(
                      children: <Widget>[
                        Text(
                          '確認',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              decoration: TextDecoration.none,
                              color: Color.fromRGBO(0, 0, 0, 1),
                              fontFamily: 'MPLUSRounded1c',
                              fontSize: 20,
                              height: 1
                          ),
                        ),
                      ],
                    ),
                  )
              )
            ),
            Positioned( //略過
                top: 720,
                left: 200,
                child: TextButton(
                    onPressed: () {
                       _showPopUp(context); //浮動視窗
                    },
                    child: Container(
                      width: 135,
                      height: 50,
                      decoration: BoxDecoration(
                        borderRadius : BorderRadius.only(
                          topLeft: Radius.circular(30),
                          topRight: Radius.circular(30),
                          bottomLeft: Radius.circular(30),
                          bottomRight: Radius.circular(30),
                        ),
                        color : Color.fromRGBO(255, 255, 255, 0.6000000238418579),
                      ),
                      padding: EdgeInsets.symmetric(horizontal: 24, vertical: 14).copyWith(left: 45, top: 9, bottom: 9, right: 45),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: <Widget>[
                          Text(
                            '略過',
                            textAlign: TextAlign.left,
                            style: TextStyle(
                                decoration: TextDecoration.none,
                                color: Color.fromRGBO(0, 0, 0, 1),
                                fontFamily: 'MPLUSRounded1c',
                                fontSize: 20,
                                height: 1
                            ),
                          ),
                        ],
                      ),
                    )
                )
            ),
            Positioned( //文字框
                top: 555,
                left: 38,
                right: 38,
                child: Container(
                    width: 300,
                    height: 150,
                    decoration: BoxDecoration(
                      borderRadius : BorderRadius.only(
                        topLeft: Radius.circular(20),
                        topRight: Radius.circular(20),
                        bottomLeft: Radius.circular(20),
                        bottomRight: Radius.circular(20),
                      ),
                      color : Color.fromRGBO(195, 231, 246, 0.5),
                    )
                )
            ),
            Positioned( //提示文字
              top: 605,
              left: 60,
              right: 53,
              child: Text(
                '請在白色牆壁或是地面等容易區分服飾的背景進行拍攝。若無洗滌標籤，請略過此拍攝。',
                textAlign: TextAlign.left,
                style: TextStyle(
                  decoration: TextDecoration.none,
                  color: Color.fromRGBO(0, 0, 0, 1),
                  fontFamily: 'MPLUSRounded1c',
                  fontSize: 15,
                  height: 1.5
                ),
              )
            ),
            Positioned( //提示文字
              top: 575,
              left: 60,
              child: Text(
                '‼️注意事項',
                textAlign: TextAlign.left,
                style: TextStyle(
                  decoration: TextDecoration.none,
                  color: Colors.redAccent,
                  fontFamily: 'MPLUSRounded1c',
                  fontSize: 15,
                  height: 1.5
                ),
              )
            ),
          ]
        )
    );
  }
}