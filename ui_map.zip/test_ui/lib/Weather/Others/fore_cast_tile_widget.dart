import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class ForeCastTileWidget extends StatelessWidget{
  String? temp;
  String? imageUrl;
  String? time;

  ForeCastTileWidget({super.key, required this.temp, required this.time, required this.imageUrl});

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Color.fromRGBO(153, 205, 246, 0.7725490196078432),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
                temp ?? '',
                style: const TextStyle(
                    decoration: TextDecoration.none,
                    color: Colors.black,
                    fontFamily: 'MPLUSRounded1c',
                    fontSize: 20,
                    height: 1
                )
            ),
            CachedNetworkImage(
              imageUrl: imageUrl ?? '',
              height: 80,
              width: 80,
              fit: BoxFit.fill,
              progressIndicatorBuilder: (context,url,downloadProgress) => const CircularProgressIndicator(),
              errorWidget: (context,url,err) => const Icon(
                Icons.image,
                color: Colors.blueAccent,
              ),
            ),
            Text(
                time ?? '',
                style: const TextStyle(
                    decoration: TextDecoration.none,
                    color: Colors.black,
                    fontFamily: 'MPLUSRounded1c',
                    fontSize: 10,
                    height: 1
                )
            ),
          ],
        ),
      ),
    );
  }
}