import 'package:flutter/material.dart';

// ignore: must_be_immutable
class WeatherTileWidget extends StatelessWidget{
  BuildContext? context;
  String? title;
  double? titleFontSize;
  String? subTitle;

  WeatherTileWidget(
      {super.key, this.context, this.title, this.titleFontSize, this.subTitle});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Center(
          child: Text(
            title ?? '',
            style: TextStyle(
                decoration: TextDecoration.none,
                color: Colors.black,
                fontFamily: 'MPLUSRounded1c',
                fontSize: 23,
                height: 1
            ),
          ),
        ),
        SizedBox(height: MediaQuery.of(context).size.height/250,),
        Center(
          child: Text(
            subTitle ?? '',
            style: const TextStyle(
                decoration: TextDecoration.none,
                color: Colors.black,
                fontFamily: 'MPLUSRounded1c',
                fontSize: 10,
                height: 1
            ),
          ),
        ),
      ],
    );
  }
}