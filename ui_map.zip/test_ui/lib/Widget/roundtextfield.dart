import 'package:flutter/material.dart';

class RoundTextField extends StatelessWidget {
  final TextEditingController? textEditingController;
  final FormFieldValidator?  validator;
  final ValueChanged<String>? onChanged;
  final String hintText;
  final TextInputType textInputType;
  final bool isObsecureText;
  final Widget? rightIcon;

  const RoundTextField(
      {super.key,
        this.textEditingController,
        this.validator,
        this.onChanged,
        required this.hintText,
        required this.textInputType,
        this.isObsecureText = false,
        this.rightIcon,
        });

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Material(
        color: Colors.transparent,
        child: TextFormField(
          controller: textEditingController,
          keyboardType: textInputType,
          obscureText: isObsecureText,
          onChanged: onChanged,
          decoration: InputDecoration(
            contentPadding: EdgeInsets.symmetric(vertical: 18).copyWith(left: 20),
            filled: true,
            fillColor: Colors.lightBlue[50],
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(30),
              borderSide: BorderSide(
                  color: Colors.transparent
              )
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(30),
              borderSide: BorderSide(color: Colors.transparent)
            ),
            hintText: hintText,
            hintStyle: TextStyle(
                decoration: TextDecoration.none,
                color: Colors.grey,
                fontFamily: "MPLUSRounded1c",
                fontSize: 15
            ),
            /*prefixIcon: Container(
              alignment: Alignment.centerLeft,
              width: 0,
              height: 10,
            ),*/
            suffixIcon: rightIcon,
          ),
          validator: validator,
          style: TextStyle(
            decoration: TextDecoration.none,
            color: Colors.black,
            fontFamily: "MPLUSRounded1c",
            fontSize: 20,
          ),
        ),
      )
    );
  }
}