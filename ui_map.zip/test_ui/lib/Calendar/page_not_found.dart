import 'package:flutter/material.dart';


import 'components/widgets.dart';
import 'utils/font_sizes.dart';

class PageNotFound extends StatefulWidget {
  const PageNotFound({super.key});

  @override
  State<PageNotFound> createState() => _PageNotFoundState();
}

class _PageNotFoundState extends State<PageNotFound> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Color.fromRGBO(232, 252, 255, 1),
        body: Center(child:Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            buildText(
                '找不到此頁面',
                Colors.black,
                textBold,
                FontWeight.w600,
                TextAlign.center,
                TextOverflow.clip),
            const SizedBox(height: 10,),
            buildText(
                '系統有問題，請立即通知開發人員',
                Colors.black,
                textTiny,
                FontWeight.normal,
                TextAlign.center,
                TextOverflow.clip),
          ],)));
  }
}
