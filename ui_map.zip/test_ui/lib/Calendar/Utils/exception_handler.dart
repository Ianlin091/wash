import 'dart:io';

String handleException(dynamic exception) {
  if (exception is FormatException) {
    return '請輸入正確的格式';
  } else if (exception is PathAccessException) {
    return '無法載入';
  } else {
    return '意料之外的問題發生。請稍後再試!';
  }
}